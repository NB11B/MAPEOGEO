# PCT Goal Solver V2 — Composition Stress Campaign

**Scientific status:** SUPPORTED

V2 is a prospective composition-stress campaign. Its first sealed execution freezes the scientific result; CI status and artifact hashes are provenance, not scientific gates.

## Sealed mode results

| Mode | Correct outcomes | Wrong positives | Families | Multi-step families | Cross-class families | Mean states | Mean primitive executions |
|---|---:|---:|---:|---:|---:|---:|---:|
| EXPLICIT/PRIMITIVE | 23 | 0 | 12 | 11 | 3 | 3.96 | 1.96 |
| EXPLICIT/SYNTHESIZED | 23 | 0 | 12 | 11 | 3 | 2.58 | 2.17 |
| INFERRED/PRIMITIVE | 23 | 0 | 12 | 11 | 3 | 3.96 | 1.96 |
| INFERRED/SYNTHESIZED | 23 | 0 | 12 | 11 | 3 | 3.67 | 2.12 |
| HYBRID/PRIMITIVE | 23 | 0 | 12 | 11 | 3 | 3.96 | 1.96 |
| HYBRID/SYNTHESIZED | 23 | 0 | 12 | 11 | 3 | 3.67 | 2.12 |

## Frozen gates

- **PASS** — `explicit_zero_wrong_positives`
- **PASS** — `explicit_ten_multistep_families`
- **PASS** — `three_cross_class_families`
- **PASS** — `g6_g8_g9_cross_class`
- **PASS** — `all_positive_results_independently_verified`
- **PASS** — `inferred_all_12_families_type_blind`
- **PASS** — `inferred_zero_control_wrong_positives`
- **PASS** — `hybrid_preserves_controls_and_family_coverage`
- **PASS** — `macro_preserves_correct_primitive_semantics`
- **PASS** — `macro_reduces_search_on_correct_cases`

## Scientific conclusions

### COMPOSITION_DEPTH

**SUPPORTED**

- multi_step_families: G1, G10, G12, G2, G3, G4, G5, G6, G7, G8, G9
- multi_step_family_count: 11
- wrong_positive_count: 0

### CROSS_REPRESENTATION_COMPOSITION

**SUPPORTED**

- cross_class_families: G6, G8, G9
- cross_class_family_count: 3
- required_cross_class_families: G6, G8, G9

### TYPE_BLIND_ROUTING

**SUPPORTED**

- inferred_correct_outcome_families: G1, G10, G11, G12, G2, G3, G4, G5, G6, G7, G8, G9
- inferred_wrong_positive_count: 0
- inferred_control_wrong_positive_count: 0
- hybrid_correct_outcome_families: G1, G10, G11, G12, G2, G3, G4, G5, G6, G7, G8, G9

### MACRO_PRESERVATION

**SUPPORTED**

- correct_primitive_semantic_change_count: 0
- credited_reduction_count: 26
- macro_used_case_count: 26

## Claim boundary

Supported scope: structured G1-G12 exact/symbolic/numerical goals under frozen V2 evidence obligations and the 35-operator executable universe.

Not claimed:
- natural-language mathematical understanding
- unrestricted theorem proving
- correctness outside the frozen operator/verifier contracts
- novel theorem status for macros or representation bridges
