#!/usr/bin/env python3
from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import re
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path
from typing import Iterable, NamedTuple

import fitz  # PyMuPDF

SOURCE_URL = "https://www.cis.upenn.edu/~jean/math-deep.pdf"
SOURCE_TITLE = (
    "Algebra, Topology, Differential Calculus, and Optimization Theory "
    "for Computer Science and Machine Learning"
)
SOURCE_AUTHORS = ["Jean Gallier", "Jocelyn Quaintance"]

CHAPTERS = [
    "Introduction",
    "Groups, Rings, and Fields",
    "Vector Spaces, Bases, Linear Maps",
    "Matrices and Linear Maps",
    "Haar Bases, Haar Wavelets, Hadamard Matrices",
    "Direct Sums",
    "Determinants",
    "Gaussian Elimination, LU, Cholesky, Echelon Form",
    "Vector Norms and Matrix Norms",
    "Iterative Methods for Solving Linear Systems",
    "The Dual Space and Duality",
    "Euclidean Spaces",
    "QR-Decomposition for Arbitrary Matrices",
    "Hermitian Spaces",
    "Eigenvectors and Eigenvalues",
    "Unit Quaternions and Rotations in SO(3)",
    "Spectral Theorems",
    "Computing Eigenvalues and Eigenvectors",
    "Introduction to The Finite Elements Method",
    "Graphs and Graph Laplacians; Basic Facts",
    "Spectral Graph Drawing",
    "Singular Value Decomposition and Polar Form",
    "Applications of SVD and Pseudo-Inverses",
    "Basics of Affine Geometry",
    "Embedding an Affine Space in a Vector Space",
    "Basics of Projective Geometry",
    "The Cartan-Dieudonne Theorem",
    "Isometries of Hermitian Spaces",
    "The Geometry of Bilinear Forms; Witt's Theorem",
    "Polynomials, Ideals and PID's",
    "Annihilating Polynomials; Primary Decomposition",
    "UFD's, Noetherian Rings, Hilbert's Basis Theorem",
    "Tensor Algebras",
    "Exterior Tensor Powers and Exterior Algebras",
    "Introduction to Modules; Modules over a PID",
    "Normal Forms; The Rational Canonical Form",
    "Topology",
    "A Detour On Fractals",
    "Differential Calculus",
    "Extrema of Real-Valued Functions",
    "Newton's Method and Its Generalizations",
    "Quadratic Optimization Problems",
    "Schur Complements and Applications",
    "Convex Sets, Cones, H-Polyhedra",
    "Linear Programs",
    "The Simplex Algorithm",
    "Linear Programming and Duality",
    "Basics of Hilbert Spaces",
    "General Results of Optimization Theory",
    "Introduction to Nonlinear Optimization",
    "Subgradients and Subdifferentials",
    "Dual Ascent Methods; ADMM",
    "Ridge Regression and Lasso Regression",
    "Positive Definite Kernels",
    "Soft Margin Support Vector Machines",
    "Total Orthogonal Families in Hilbert Spaces",
    "Zorn's Lemma; Some Applications",
]

DECL_KINDS = (
    "Definition",
    "Proposition",
    "Theorem",
    "Lemma",
    "Corollary",
    "Claim",
    "Fact",
)
KIND_ALT = "|".join(DECL_KINDS)
FULL_DECL_RE = re.compile(
    rf"^\s*(?P<kind>{KIND_ALT})\s+(?P<number>\d+(?:\.\d+)+)\b",
    re.IGNORECASE,
)
KIND_ONLY_RE = re.compile(rf"^\s*(?P<kind>{KIND_ALT})\s*[\.:]?\s*$", re.IGNORECASE)
NUMBER_PREFIX_RE = re.compile(r"^\s*(?P<number>\d+(?:\.\d+)+)\b")
PROOF_RE = re.compile(r"^\s*Proof\s*[\.:]?\s*", re.IGNORECASE)
REF_RE = re.compile(
    rf"\b(?P<kind>{KIND_ALT})\s+(?P<number>\d+(?:\.\d+)+)\b",
    re.IGNORECASE,
)


def normalize_text(text: str) -> str:
    # NFKC is deliberate: it expands presentation ligatures such as "ﬁ" in
    # "Deﬁnition" without preserving source prose in persistent artifacts.
    text = unicodedata.normalize("NFKC", text)
    text = text.replace("\u00ad", "")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_text(text: str) -> str:
    return sha256_bytes(text.encode("utf-8"))


def canonical_kind(kind: str) -> str:
    low = kind.lower()
    for candidate in DECL_KINDS:
        if candidate.lower() == low:
            return candidate
    return kind.title()


def decl_key(kind: str, number: str) -> tuple[str, str]:
    return canonical_kind(kind).lower(), number


def decl_node_id(kind: str, number: str) -> str:
    return f"srcdecl:{canonical_kind(kind).lower()}:{number.replace('.', '_')}"


def proof_node_id(kind: str, number: str) -> str:
    return f"proof:{canonical_kind(kind).lower()}:{number.replace('.', '_')}"


def load_json_any(path: Path) -> dict:
    if path.suffix == ".gz":
        with gzip.open(path, "rt", encoding="utf-8") as f:
            return json.load(f)
    return json.loads(path.read_text(encoding="utf-8"))


def save_json(path: Path, obj: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, sort_keys=False), encoding="utf-8")


def extract_line_stream(pdf_path: Path) -> tuple[list[dict], dict]:
    pdf_bytes = pdf_path.read_bytes()
    doc = fitz.open(pdf_path)
    lines: list[dict] = []
    nonempty_pages = 0
    total_chars = 0
    for page_index, page in enumerate(doc):
        text = page.get_text("text", sort=True)
        if text.strip():
            nonempty_pages += 1
        total_chars += len(text)
        for local_line, raw in enumerate(text.splitlines(), start=1):
            line = normalize_text(raw)
            if not line:
                continue
            lines.append({"pdf_page": page_index + 1, "local_line": local_line, "text": line})
    meta = {
        "pdf_sha256": sha256_bytes(pdf_bytes),
        "pdf_size_bytes": len(pdf_bytes),
        "pdf_pages": doc.page_count,
        "nonempty_pages": nonempty_pages,
        "extracted_nonempty_lines": len(lines),
        "extracted_characters": total_chars,
    }
    doc.close()
    return lines, meta


class Start(NamedTuple):
    line_index: int
    kind: str
    number: str
    heading_mode: str


def declaration_starts(lines: list[dict]) -> list[Start]:
    starts: list[Start] = []
    used: set[int] = set()
    for i, rec in enumerate(lines):
        if i in used:
            continue
        m = FULL_DECL_RE.match(rec["text"])
        if m:
            starts.append(Start(i, canonical_kind(m.group("kind")), m.group("number"), "SAME_LINE"))
            continue
        k = KIND_ONLY_RE.match(rec["text"])
        if k and i + 1 < len(lines):
            n = NUMBER_PREFIX_RE.match(lines[i + 1]["text"])
            if n:
                starts.append(Start(i, canonical_kind(k.group("kind")), n.group("number"), "SPLIT_LINE"))
                used.add(i + 1)
    starts.sort(key=lambda s: s.line_index)
    return starts


# Controlled, non-prose semantic ontology. Patterns are intentionally broad
# mathematical vocabulary; output stores only concept labels, never source text.
CONCEPT_PATTERNS: dict[str, tuple[str, ...]] = {
    "ALGEBRAIC_STRUCTURE": (r"\bgroup\b", r"\bsubgroup\b", r"\bring\b", r"\bfield\b", r"\bideal\b", r"\bhomomorph", r"\bisomorph"),
    "VECTOR_SPACE": (r"\bvector space\b", r"\bsubspace\b", r"\bbasis\b", r"\blinear map\b", r"\blinear transformation\b"),
    "MATRIX_OPERATOR": (r"\bmatrix\b", r"\bmatrices\b", r"\bmatrix representation\b"),
    "DIRECT_SUM": (r"\bdirect sum\b", r"\bdecomposition\b"),
    "DETERMINANT_VOLUME": (r"\bdeterminant\b", r"\bdet\b", r"\boriented volume\b"),
    "NORM_METRIC": (r"\bnorm\b", r"\bdistance\b", r"\bmetric\b", r"\binner product\b", r"\borthogonal"),
    "DUALITY": (r"\bdual space\b", r"\bduality\b", r"\bdual map\b", r"\badjoint\b"),
    "FACTORIZATION": (r"\bQR\b", r"\bLU\b", r"\bCholesky\b", r"\bfactorization\b", r"\bdecomposition\b"),
    "EIGEN_SPECTRAL": (r"\beigenvalue\b", r"\beigenvector\b", r"\bspectrum\b", r"\bspectral\b"),
    "ROTATION_QUATERNION": (r"\bquaternion\b", r"\brotation\b", r"\bSO\s*\(\s*3\s*\)", r"\borthogonal transformation\b"),
    "GRAPH_RELATION": (r"\bgraph\b", r"\bvertex\b", r"\bedge\b", r"\badjacency\b", r"\bLaplacian\b"),
    "SVD_PSEUDOINVERSE": (r"\bsingular value\b", r"\bSVD\b", r"\bpseudo-?inverse\b"),
    "AFFINE_PROJECTIVE": (r"\baffine\b", r"\bprojective\b", r"\bhomogeneous coordinates?\b"),
    "BILINEAR_FORM": (r"\bbilinear\b", r"\bquadratic form\b", r"\bHermitian form\b"),
    "POLYNOMIAL_MODULE": (r"\bpolynomial\b", r"\bmodule\b", r"\bannihilat", r"\bcanonical form\b"),
    "TENSOR_PRODUCT": (r"\btensor\b", r"\btensor product\b", r"\bKronecker\b"),
    "EXTERIOR_WEDGE": (r"\bexterior\b", r"\bwedge\b", r"\balternating\b"),
    "TOPOLOGY": (r"\btopolog", r"\bopen set\b", r"\bclosed set\b", r"\bcontinuous\b", r"\bcompact\b", r"\bhomeomorph"),
    "DIFFERENTIAL_TANGENT": (r"\bderivative\b", r"\bdifferential\b", r"\bJacobian\b", r"\bgradient\b", r"\bHessian\b", r"\btangent\b"),
    "NEWTON_ITERATION": (r"\bNewton\b", r"\biteration\b", r"\biterative\b"),
    "CONVEX_GEOMETRY": (r"\bconvex\b", r"\bcone\b", r"\bpolyhed", r"\bseparat(?:ing|ion) hyperplane\b"),
    "LINEAR_PROGRAMMING": (r"\blinear program", r"\bsimplex\b", r"\bprimal\b", r"\bdual program\b"),
    "OPTIMIZATION": (r"\boptimi", r"\bminimi", r"\bmaximi", r"\bextrem", r"\bsubgradient\b", r"\bADMM\b"),
    "HILBERT_PROJECTION": (r"\bHilbert\b", r"\bprojection\b", r"\borthogonal family\b"),
    "REGRESSION": (r"\bregression\b", r"\bridge\b", r"\blasso\b", r"\bleast squares\b"),
    "KERNEL_SIMILARITY": (r"\bkernel\b", r"\bpositive definite\b", r"\bGram matrix\b", r"\bGaussian\b"),
    "MARGIN_CLASSIFIER": (r"\bsupport vector\b", r"\bmargin\b", r"\bclassifier\b"),
}
COMPILED_PATTERNS = {k: tuple(re.compile(p, re.IGNORECASE) for p in ps) for k, ps in CONCEPT_PATTERNS.items()}

# Chapter priors are a fallback and are kept distinct from direct text evidence.
CHAPTER_PRIORS: dict[int, tuple[str, ...]] = {
    2:("ALGEBRAIC_STRUCTURE",), 3:("VECTOR_SPACE",), 4:("MATRIX_OPERATOR","VECTOR_SPACE"),
    5:("VECTOR_SPACE","MATRIX_OPERATOR"), 6:("DIRECT_SUM","VECTOR_SPACE"), 7:("DETERMINANT_VOLUME",),
    8:("MATRIX_OPERATOR","FACTORIZATION"), 9:("NORM_METRIC","MATRIX_OPERATOR"), 10:("NEWTON_ITERATION","MATRIX_OPERATOR"),
    11:("DUALITY","VECTOR_SPACE"), 12:("NORM_METRIC","VECTOR_SPACE"), 13:("FACTORIZATION","MATRIX_OPERATOR"),
    14:("NORM_METRIC","DUALITY"), 15:("EIGEN_SPECTRAL","MATRIX_OPERATOR"), 16:("ROTATION_QUATERNION","NORM_METRIC"),
    17:("EIGEN_SPECTRAL",), 18:("EIGEN_SPECTRAL","NEWTON_ITERATION"), 19:("VECTOR_SPACE","MATRIX_OPERATOR"),
    20:("GRAPH_RELATION",), 21:("GRAPH_RELATION","EIGEN_SPECTRAL"), 22:("SVD_PSEUDOINVERSE","EIGEN_SPECTRAL"),
    23:("SVD_PSEUDOINVERSE","REGRESSION"), 24:("AFFINE_PROJECTIVE",), 25:("AFFINE_PROJECTIVE","VECTOR_SPACE"),
    26:("AFFINE_PROJECTIVE",), 27:("NORM_METRIC","BILINEAR_FORM"), 28:("NORM_METRIC","BILINEAR_FORM"),
    29:("BILINEAR_FORM",), 30:("POLYNOMIAL_MODULE","ALGEBRAIC_STRUCTURE"), 31:("POLYNOMIAL_MODULE",),
    32:("POLYNOMIAL_MODULE","ALGEBRAIC_STRUCTURE"), 33:("TENSOR_PRODUCT",), 34:("EXTERIOR_WEDGE","TENSOR_PRODUCT"),
    35:("POLYNOMIAL_MODULE","ALGEBRAIC_STRUCTURE"), 36:("POLYNOMIAL_MODULE","MATRIX_OPERATOR"), 37:("TOPOLOGY",),
    38:("TOPOLOGY",), 39:("DIFFERENTIAL_TANGENT",), 40:("OPTIMIZATION","DIFFERENTIAL_TANGENT"),
    41:("NEWTON_ITERATION","DIFFERENTIAL_TANGENT"), 42:("OPTIMIZATION","BILINEAR_FORM"),
    43:("MATRIX_OPERATOR","FACTORIZATION"), 44:("CONVEX_GEOMETRY",), 45:("LINEAR_PROGRAMMING","CONVEX_GEOMETRY"),
    46:("LINEAR_PROGRAMMING",), 47:("LINEAR_PROGRAMMING","DUALITY"), 48:("HILBERT_PROJECTION","NORM_METRIC"),
    49:("OPTIMIZATION","CONVEX_GEOMETRY"), 50:("OPTIMIZATION","DIFFERENTIAL_TANGENT"),
    51:("OPTIMIZATION","CONVEX_GEOMETRY"), 52:("OPTIMIZATION","DUALITY"), 53:("REGRESSION","OPTIMIZATION"),
    54:("KERNEL_SIMILARITY","NORM_METRIC"), 55:("MARGIN_CLASSIFIER","CONVEX_GEOMETRY"),
    56:("HILBERT_PROJECTION",), 57:("ALGEBRAIC_STRUCTURE",),
}

EO_FAMILIES = {
    "ALGEBRAIC_STRUCTURE":("COMPOSITION_OPERATOR",),
    "VECTOR_SPACE":("LINEAR_OPERATOR",),
    "MATRIX_OPERATOR":("MATRIX_OPERATOR",),
    "DIRECT_SUM":("DECOMPOSITION_OPERATOR",),
    "DETERMINANT_VOLUME":("SCALAR_INVARIANT_OPERATOR",),
    "NORM_METRIC":("NORM_INNER_PRODUCT_OPERATOR",),
    "DUALITY":("DUAL_ADJOINT_OPERATOR",),
    "FACTORIZATION":("FACTORIZATION_OPERATOR",),
    "EIGEN_SPECTRAL":("SPECTRAL_OPERATOR",),
    "ROTATION_QUATERNION":("ROTATION_OPERATOR",),
    "GRAPH_RELATION":("GRAPH_LAPLACIAN_OPERATOR",),
    "SVD_PSEUDOINVERSE":("SVD_PSEUDOINVERSE_OPERATOR",),
    "AFFINE_PROJECTIVE":("HOMOGENEOUS_LINEAR_OPERATOR",),
    "BILINEAR_FORM":("BILINEAR_QUADRATIC_OPERATOR",),
    "POLYNOMIAL_MODULE":("POLYNOMIAL_ACTION_OPERATOR",),
    "TENSOR_PRODUCT":("TENSOR_PRODUCT_OPERATOR",),
    "EXTERIOR_WEDGE":("WEDGE_OPERATOR",),
    "TOPOLOGY":("CONTINUITY_MAP_OPERATOR",),
    "DIFFERENTIAL_TANGENT":("DERIVATIVE_OPERATOR",),
    "NEWTON_ITERATION":("ITERATIVE_UPDATE_OPERATOR",),
    "CONVEX_GEOMETRY":("CONVEX_COMBINATION_OPERATOR",),
    "LINEAR_PROGRAMMING":("LINEAR_INEQUALITY_OPERATOR",),
    "OPTIMIZATION":("OPTIMIZATION_UPDATE_OPERATOR",),
    "HILBERT_PROJECTION":("PROJECTION_OPERATOR",),
    "REGRESSION":("REGRESSION_OPERATOR",),
    "KERNEL_SIMILARITY":("KERNEL_OPERATOR",),
    "MARGIN_CLASSIFIER":("MARGIN_DECISION_OPERATOR",),
}
GEO_FAMILIES = {
    "ALGEBRAIC_STRUCTURE":("ACTION_CAYLEY_GEOMETRY",),
    "VECTOR_SPACE":("SUBSPACE_GEOMETRY",),
    "MATRIX_OPERATOR":("TRANSFORMATION_GEOMETRY",),
    "DIRECT_SUM":("SUBSPACE_DECOMPOSITION_GEOMETRY",),
    "DETERMINANT_VOLUME":("ORIENTED_VOLUME_GEOMETRY",),
    "NORM_METRIC":("METRIC_ANGLE_GEOMETRY",),
    "DUALITY":("DUAL_PAIRING_GEOMETRY",),
    "FACTORIZATION":("FRAME_FACTOR_GEOMETRY",),
    "EIGEN_SPECTRAL":("INVARIANT_SUBSPACE_GEOMETRY",),
    "ROTATION_QUATERNION":("ROTOR_ACTION_GEOMETRY",),
    "GRAPH_RELATION":("INCIDENCE_RELATIONAL_GEOMETRY",),
    "SVD_PSEUDOINVERSE":("PRINCIPAL_AXIS_GEOMETRY",),
    "AFFINE_PROJECTIVE":("AFFINE_PROJECTIVE_GEOMETRY",),
    "BILINEAR_FORM":("FORM_SIGNATURE_GEOMETRY",),
    "POLYNOMIAL_MODULE":("MODULE_ACTION_GEOMETRY",),
    "TENSOR_PRODUCT":("MULTILINEAR_PRODUCT_GEOMETRY",),
    "EXTERIOR_WEDGE":("ORIENTED_SUBSPACE_GEOMETRY",),
    "TOPOLOGY":("NEIGHBORHOOD_CONTINUITY_GEOMETRY",),
    "DIFFERENTIAL_TANGENT":("TANGENT_LOCAL_GEOMETRY",),
    "NEWTON_ITERATION":("TANGENT_INTERSECTION_GEOMETRY",),
    "CONVEX_GEOMETRY":("CONVEX_REGION_GEOMETRY",),
    "LINEAR_PROGRAMMING":("POLYHEDRAL_DUAL_GEOMETRY",),
    "OPTIMIZATION":("OBJECTIVE_LANDSCAPE_GEOMETRY",),
    "HILBERT_PROJECTION":("ORTHOGONAL_PROJECTION_GEOMETRY",),
    "REGRESSION":("LEAST_SQUARES_PROJECTION_GEOMETRY",),
    "KERNEL_SIMILARITY":("SIMILARITY_DISTANCE_GEOMETRY",),
    "MARGIN_CLASSIFIER":("SEPARATING_MARGIN_GEOMETRY",),
}


def profile_segment(segment_text: str, chapter: int | None) -> dict:
    direct = []
    for concept, patterns in COMPILED_PATTERNS.items():
        if any(p.search(segment_text) for p in patterns):
            direct.append(concept)
    direct = sorted(set(direct))
    priors = sorted(set(CHAPTER_PRIORS.get(chapter or -1, ())))
    selected = direct if direct else priors
    evidence = "DIRECT_TEXT" if direct else ("CHAPTER_PRIOR" if priors else "NONE")
    eo = sorted({fam for concept in selected for fam in EO_FAMILIES.get(concept, ())})
    geo = sorted({fam for concept in selected for fam in GEO_FAMILIES.get(concept, ())})
    if eo and geo:
        status = "DUAL_CANDIDATE"
    elif eo:
        status = "EO_ONLY_CANDIDATE"
    elif geo:
        status = "GEO_ONLY_CANDIDATE"
    else:
        status = "UNCLASSIFIED"
    return {
        "direct_concepts": direct,
        "chapter_prior_concepts": priors,
        "selected_concepts": selected,
        "evidence": evidence,
        "eo_candidate_families": eo,
        "geo_candidate_families": geo,
        "dualization_status": status,
    }


def find_declarations(lines: list[dict]) -> list[dict]:
    starts = declaration_starts(lines)
    out = []
    for pos, st in enumerate(starts):
        end = starts[pos + 1].line_index if pos + 1 < len(starts) else len(lines)
        records = lines[st.line_index:end]
        segment_text = normalize_text("\n".join(r["text"] for r in records))
        chapter = int(st.number.split(".")[0]) if st.number.split(".")[0].isdigit() else None
        if chapter is not None and not (1 <= chapter <= len(CHAPTERS)):
            chapter = None
        proof_offset = None
        for j, rec in enumerate(records):
            if PROOF_RE.match(rec["text"]):
                proof_offset = j
                break
        proof_text = ""
        refs = []
        if proof_offset is not None:
            proof_text = normalize_text("\n".join(r["text"] for r in records[proof_offset:]))
            seen = set()
            for m in REF_RE.finditer(proof_text):
                rk, rn = canonical_kind(m.group("kind")), m.group("number")
                key = (rk.lower(), rn)
                if key == (st.kind.lower(), st.number) or key in seen:
                    continue
                seen.add(key)
                refs.append({"kind": rk, "number": rn})
        profile = profile_segment(segment_text, chapter)
        out.append({
            "kind": st.kind,
            "number": st.number,
            "chapter": chapter,
            "chapter_title": CHAPTERS[chapter - 1] if chapter else None,
            "pdf_page_start": records[0]["pdf_page"],
            "pdf_page_end": records[-1]["pdf_page"],
            "heading_mode": st.heading_mode,
            "source_segment_sha256": sha256_text(segment_text),
            "source_segment_chars": len(segment_text),
            "proof_present": proof_offset is not None,
            "proof_sha256": sha256_text(proof_text) if proof_text else None,
            "proof_chars": len(proof_text),
            "proof_references": refs,
            "semantic_profile": profile,
        })
    return out


def dedupe_declarations(declarations: list[dict]) -> tuple[list[dict], list[dict]]:
    grouped: dict[tuple[str, str], list[dict]] = defaultdict(list)
    for d in declarations:
        grouped[decl_key(d["kind"], d["number"])].append(d)
    kept, dropped = [], []
    for key, candidates in grouped.items():
        winner = max(candidates, key=lambda d: (d["source_segment_chars"], d["pdf_page_start"]))
        kept.append(winner)
        for d in candidates:
            if d is winner:
                continue
            dropped.append({
                "kind": d["kind"], "number": d["number"],
                "pdf_page_start": d["pdf_page_start"], "pdf_page_end": d["pdf_page_end"],
                "source_segment_sha256": d["source_segment_sha256"],
                "reason": "duplicate_semantic_key",
                "winner_pdf_page_start": winner["pdf_page_start"],
            })
    kept.sort(key=lambda d: (d["chapter"] or 999, tuple(int(x) for x in d["number"].split(".")), d["kind"]))
    return kept, dropped


def ensure_source_scaffold(graph: dict) -> tuple[dict[int, str], str]:
    nodes, edges = graph.setdefault("nodes", []), graph.setdefault("edges", [])
    ids, eids = {n.get("id") for n in nodes}, {e.get("id") for e in edges}
    book = "src:book"
    if book not in ids:
        nodes.append({"id":book,"type":"SOURCE","label":SOURCE_TITLE,"attributes":{"url":SOURCE_URL,"authors":SOURCE_AUTHORS}})
        ids.add(book)
    chapter_ids = {}
    for i, title in enumerate(CHAPTERS, start=1):
        cid = f"src:chapter:{i:02d}"; chapter_ids[i] = cid
        if cid not in ids:
            nodes.append({"id":cid,"type":"SOURCE","label":f"Chapter {i}: {title}","attributes":{"chapter_number":i,"title":title}})
            ids.add(cid)
        eid = f"e:book:chapter:{i:02d}"
        if eid not in eids:
            edges.append({"id":eid,"type":"CONTAINS","source":book,"target":cid,"ordinal":i}); eids.add(eid)
    return chapter_ids, book


def ontology_node_id(prefix: str, name: str) -> str:
    return f"ontology:{prefix}:{name.lower()}"


def merge_into_graph(base_graph: dict, declarations: list[dict]) -> tuple[dict, dict]:
    graph = json.loads(json.dumps(base_graph))
    nodes, edges = graph.setdefault("nodes", []), graph.setdefault("edges", [])
    chapter_ids, _ = ensure_source_scaffold(graph)
    node_ids, edge_ids = {n["id"] for n in nodes}, {e["id"] for e in edges}

    # Controlled ontology nodes.
    all_concepts = sorted(CONCEPT_PATTERNS)
    all_eo = sorted({x for vals in EO_FAMILIES.values() for x in vals})
    all_geo = sorted({x for vals in GEO_FAMILIES.values() for x in vals})
    for concept in all_concepts:
        nid=ontology_node_id("concept",concept)
        if nid not in node_ids:
            nodes.append({"id":nid,"type":"OBJECT","label":concept,"attributes":{"ontology":"MAPEOGEO_CONTROLLED_CONCEPT_V0_5"}}); node_ids.add(nid)
    for fam in all_eo:
        nid=ontology_node_id("eo",fam)
        if nid not in node_ids:
            nodes.append({"id":nid,"type":"OPERATOR","label":fam,"view":"EO","attributes":{"ontology":"MAPEOGEO_EO_FAMILY_V0_5","status":"CANDIDATE_FAMILY"}}); node_ids.add(nid)
    for fam in all_geo:
        nid=ontology_node_id("geo",fam)
        if nid not in node_ids:
            nodes.append({"id":nid,"type":"OPERATOR","label":fam,"view":"GEO","attributes":{"ontology":"MAPEOGEO_GEO_FAMILY_V0_5","status":"CANDIDATE_FAMILY"}}); node_ids.add(nid)

    key_to_node = {}
    proof_nodes = set()
    for d in declarations:
        nid=decl_node_id(d["kind"],d["number"]); key_to_node[decl_key(d["kind"],d["number"])]=nid
        attrs={
            "declaration_kind":d["kind"],"number":d["number"],"chapter":d["chapter"],
            "pdf_page_start":d["pdf_page_start"],"pdf_page_end":d["pdf_page_end"],
            "heading_mode":d["heading_mode"],"source_segment_sha256":d["source_segment_sha256"],
            "source_segment_chars":d["source_segment_chars"],"proof_present":d["proof_present"],
            "proof_sha256":d["proof_sha256"],"proof_chars":d["proof_chars"],
            "semantic_profile":d["semantic_profile"],"dualization_status":d["semantic_profile"]["dualization_status"],
            "source":"GALLIER_QUAINTANCE_MATH_DEEP","source_url":SOURCE_URL,
        }
        if nid not in node_ids:
            nodes.append({"id":nid,"type":"STATEMENT","label":f"{d['kind']} {d['number']}","attributes":attrs}); node_ids.add(nid)
        if d["chapter"]:
            eid=f"e:source:{d['kind'].lower()}:{d['number'].replace('.','_')}:chapter"
            if eid not in edge_ids:
                edges.append({"id":eid,"type":"SOURCED_FROM","source":nid,"target":chapter_ids[d["chapter"]]}); edge_ids.add(eid)
        p=d["semantic_profile"]
        for concept in p["selected_concepts"]:
            eid=f"e:concept:{d['kind'].lower()}:{d['number'].replace('.','_')}:{concept.lower()}"
            if eid not in edge_ids:
                edges.append({"id":eid,"type":"HAS_CONCEPT","source":nid,"target":ontology_node_id('concept',concept),"attributes":{"evidence":p["evidence"]}}); edge_ids.add(eid)
        for fam in p["eo_candidate_families"]:
            eid=f"e:candidate:eo:{d['kind'].lower()}:{d['number'].replace('.','_')}:{fam.lower()}"
            if eid not in edge_ids:
                edges.append({"id":eid,"type":"CANDIDATE_EO","source":nid,"target":ontology_node_id('eo',fam),"attributes":{"status":"HEURISTIC_CANDIDATE","evidence":p["evidence"]}}); edge_ids.add(eid)
        for fam in p["geo_candidate_families"]:
            eid=f"e:candidate:geo:{d['kind'].lower()}:{d['number'].replace('.','_')}:{fam.lower()}"
            if eid not in edge_ids:
                edges.append({"id":eid,"type":"CANDIDATE_GEO","source":nid,"target":ontology_node_id('geo',fam),"attributes":{"status":"HEURISTIC_CANDIDATE","evidence":p["evidence"]}}); edge_ids.add(eid)
        if d["proof_present"]:
            pid=proof_node_id(d["kind"],d["number"]); proof_nodes.add(pid)
            if pid not in node_ids:
                nodes.append({"id":pid,"type":"PROOF_STEP","label":f"Proof block for {d['kind']} {d['number']}","attributes":{"status":"SOURCE_PROOF_BLOCK","proof_sha256":d["proof_sha256"],"proof_chars":d["proof_chars"],"source_statement":nid}}); node_ids.add(pid)
            peid=f"e:proof:{d['kind'].lower()}:{d['number'].replace('.','_')}:produces"
            if peid not in edge_ids:
                edges.append({"id":peid,"type":"PRODUCES","source":pid,"target":nid,"attributes":{"evidence":"SOURCE_PROOF_BLOCK"}}); edge_ids.add(peid)

    resolved=0; unresolved=[]; dep_seen=set()
    for d in declarations:
        if not d["proof_present"]: continue
        source=key_to_node[decl_key(d["kind"],d["number"])]; proof=proof_node_id(d["kind"],d["number"])
        for ref in d["proof_references"]:
            target=key_to_node.get(decl_key(ref["kind"],ref["number"]))
            if not target:
                unresolved.append({"source_kind":d["kind"],"source_number":d["number"],"target_kind":ref["kind"],"target_number":ref["number"]}); continue
            pair=(source,target)
            if pair in dep_seen: continue
            dep_seen.add(pair); resolved+=1
            base=f"e:proofref:{d['kind'].lower()}:{d['number'].replace('.','_')}:{ref['kind'].lower()}:{ref['number'].replace('.','_')}"
            if base not in edge_ids:
                edges.append({"id":base,"type":"DEPENDS_ON","source":source,"target":target,"attributes":{"evidence":"SOURCE_PROOF_CROSS_REFERENCE","proof_node":proof}}); edge_ids.add(base)
            prem=base+":premise"
            if prem not in edge_ids:
                edges.append({"id":prem,"type":"PREMISE","source":target,"target":proof,"attributes":{"evidence":"SOURCE_PROOF_CROSS_REFERENCE"}}); edge_ids.add(prem)
    graph["schema_version"]="0.5.0"
    graph["graph_id"]="MAPEOGEO-GALLIER-QUAINTANCE-V0.5"
    return graph,{"resolved_dependency_references":resolved,"unresolved_dependency_references":len(unresolved),"unresolved_references":unresolved}


def audit_graph(graph: dict) -> dict:
    nodes,edges=graph.get("nodes",[]),graph.get("edges",[])
    nids=[n.get("id") for n in nodes]; eids=[e.get("id") for e in edges]; by=set(nids)
    forbidden={"text","excerpt","statement_text","proof_text","source_text","body","segment_text"}
    bad=[]
    for n in nodes:
        hit=forbidden.intersection(n.get("attributes",{}))
        if hit: bad.append({"id":n.get("id"),"fields":sorted(hit)})
    return {"unique_node_ids":len(nids)==len(set(nids)),"unique_edge_ids":len(eids)==len(set(eids)),"all_edge_endpoints_exist":all(e.get("source") in by and e.get("target") in by for e in edges),"no_copyright_payload_fields":not bad,"payload_violations":bad}


def fixture_ontology_recovery(base_graph: dict) -> dict:
    fixtures=[n for n in base_graph.get("nodes",[]) if n.get("id","").startswith("obj:test:")]
    recovered=[]; missing=[]
    for n in fixtures:
        label=n.get("label","")
        # Add EO/GEO representation strings if linked in base graph.
        rep=[]
        for e in base_graph.get("edges",[]):
            if e.get("type")=="REPRESENTS" and e.get("target")==n.get("id"):
                src=next((x for x in base_graph.get("nodes",[]) if x.get("id")==e.get("source")),None)
                if src: rep.append(src.get("attributes",{}).get("representation",""))
        prof=profile_segment(" ".join([label,*rep]),n.get("attributes",{}).get("source_chapter"))
        if prof["eo_candidate_families"] and prof["geo_candidate_families"]:
            recovered.append(n.get("id"))
        else: missing.append(n.get("id"))
    return {"total":len(fixtures),"recovered":len(recovered),"missing":missing}


def main() -> int:
    ap=argparse.ArgumentParser(description="MAPEOGEO v0.5 corpus ingestion + controlled EO/GEO candidate dualization audit")
    ap.add_argument("pdf",type=Path)
    ap.add_argument("--base-graph",type=Path,required=True)
    ap.add_argument("--out-dir",type=Path,required=True)
    ap.add_argument("--min-declarations",type=int,default=891)
    ap.add_argument("--min-chapters",type=int,default=55)
    ap.add_argument("--min-proofs",type=int,default=587)
    ap.add_argument("--min-resolved-deps",type=int,default=626)
    ap.add_argument("--max-unresolved-rate",type=float,default=0.101)
    ap.add_argument("--min-direct-tag-coverage",type=float,default=0.60)
    ap.add_argument("--min-dual-candidate-coverage",type=float,default=0.95)
    args=ap.parse_args(); args.out_dir.mkdir(parents=True,exist_ok=True)

    lines,pdf_meta=extract_line_stream(args.pdf)
    raw=find_declarations(lines); decls,dropped=dedupe_declarations(raw)
    base=load_json_any(args.base_graph)
    fixture_recovery=fixture_ontology_recovery(base)
    graph,deps=merge_into_graph(base,decls); audit=audit_graph(graph)

    kinds=Counter(d["kind"] for d in decls); chapters=sorted({d["chapter"] for d in decls if d["chapter"]})
    proofs=sum(d["proof_present"] for d in decls); xrefs=sum(len(d["proof_references"]) for d in decls)
    direct=sum(bool(d["semantic_profile"]["direct_concepts"]) for d in decls)
    dual=sum(d["semantic_profile"]["dualization_status"]=="DUAL_CANDIDATE" for d in decls)
    unclassified=sum(d["semantic_profile"]["dualization_status"]=="UNCLASSIFIED" for d in decls)
    split=sum(d["heading_mode"]=="SPLIT_LINE" for d in decls)
    direct_rate=direct/len(decls) if decls else 0.0; dual_rate=dual/len(decls) if decls else 0.0
    unresolved_rate=deps["unresolved_dependency_references"]/xrefs if xrefs else 0.0
    definitions=kinds.get("Definition",0)

    gates={
        "declarations_not_regressed":len(decls)>=args.min_declarations,
        "chapter_coverage_not_regressed":len(chapters)>=args.min_chapters,
        "proof_blocks_not_regressed":proofs>=args.min_proofs,
        "resolved_dependencies_not_regressed":deps["resolved_dependency_references"]>=args.min_resolved_deps,
        "unresolved_reference_rate_not_worse":unresolved_rate<=args.max_unresolved_rate,
        "definition_parser_recovered_definitions":definitions>0,
        "direct_semantic_tag_coverage":direct_rate>=args.min_direct_tag_coverage,
        "dual_candidate_coverage":dual_rate>=args.min_dual_candidate_coverage,
        "v0_3_fixture_ontology_recovery":fixture_recovery["total"]==20 and fixture_recovery["recovered"]==20,
        "unique_node_ids":audit["unique_node_ids"],"unique_edge_ids":audit["unique_edge_ids"],
        "all_edge_endpoints_exist":audit["all_edge_endpoints_exist"],"copyright_payload_policy":audit["no_copyright_payload_fields"],
    }
    status="PASS" if all(gates.values()) else "FAIL"
    profiles=[{
        "kind":d["kind"],"number":d["number"],"chapter":d["chapter"],"pdf_page_start":d["pdf_page_start"],"pdf_page_end":d["pdf_page_end"],
        "heading_mode":d["heading_mode"],"source_segment_sha256":d["source_segment_sha256"],"source_segment_chars":d["source_segment_chars"],
        "proof_present":d["proof_present"],"proof_sha256":d["proof_sha256"],"proof_chars":d["proof_chars"],"proof_references":d["proof_references"],
        "semantic_profile":d["semantic_profile"],
    } for d in decls]
    report={
        "audit_id":"MAPEOGEO-CORPUS-DUALIZATION-V0.5","status":status,
        "source":{"title":SOURCE_TITLE,"authors":SOURCE_AUTHORS,"url":SOURCE_URL,"redistributed":False,"copyright_payload_policy":"CONTROLLED_METADATA_ONLY",**pdf_meta},
        "extraction":{"raw_declaration_matches":len(raw),"deduplicated_declarations":len(decls),"duplicate_candidates_dropped":len(dropped),"chapters_with_declarations":len(chapters),"covered_chapters":chapters,"proof_blocks_detected":proofs,"proof_cross_references_detected":xrefs,"declarations_by_kind":dict(sorted(kinds.items())),"split_line_headings_recovered":split},
        "dependencies":deps,
        "dualization":{"direct_tagged_declarations":direct,"direct_tag_coverage":direct_rate,"dual_candidate_declarations":dual,"dual_candidate_coverage":dual_rate,"unclassified_declarations":unclassified,"v0_3_fixture_ontology_recovery":fixture_recovery,"status_semantics":"CANDIDATE_ONLY_NOT_VERIFIED_EQUIVALENCE"},
        "graph":{"nodes":len(graph["nodes"]),"edges":len(graph["edges"]),"audit":audit},
        "gates":gates,
        "claim_boundary":{"supported":["The broad source corpus can be represented as declaration/proof-reference structure in the same graph.","A controlled ontology can assign EO and GEO candidate operator families to the corpus without persisting source prose.","The v0.3 demonstrated fixtures are fully expressible in the controlled v0.5 ontology."],"not_supported_yet":["Executable EO/GEO equivalence for all imported declarations.","Universal mathematical closure.","Automatic Lean proof generation or kernel acceptance.","Complete proof dependency reconstruction beyond explicit source references."]},
    }
    save_json(args.out_dir/"corpus_dualization_report.json",report); save_json(args.out_dir/"semantic_profiles.json",profiles); save_json(args.out_dir/"duplicate_declaration_audit.json",dropped); save_json(args.out_dir/"mapeogeo_corpus_graph.json",graph)
    summary=["# MAPEOGEO Corpus Dualization Audit v0.5","",f"**Status:** {status}","",f"- PDF pages: {pdf_meta['pdf_pages']}",f"- Declarations: {len(decls)}",f"- Definitions recovered: {definitions}",f"- Chapters with declarations: {len(chapters)} / 57",f"- Proof blocks: {proofs}",f"- Explicit proof cross-references: {xrefs}",f"- Resolved dependencies: {deps['resolved_dependency_references']}",f"- Unresolved dependencies: {deps['unresolved_dependency_references']} ({unresolved_rate:.2%})",f"- Direct semantic-tag coverage: {direct_rate:.2%}",f"- Dual EO/GEO candidate coverage: {dual_rate:.2%}",f"- v0.3 fixture ontology recovery: {fixture_recovery['recovered']} / {fixture_recovery['total']}",f"- Graph: {len(graph['nodes'])} nodes / {len(graph['edges'])} edges","","All dualization assignments are heuristic candidates until separately verified. No source prose is persisted in the artifact."]
    (args.out_dir/"V0_5_SUMMARY.md").write_text("\n".join(summary)+"\n",encoding="utf-8")
    print(f"MAPEOGEO_V0_5: {status} declarations={len(decls)} definitions={definitions} chapters={len(chapters)} proofs={proofs} resolved={deps['resolved_dependency_references']} unresolved_rate={unresolved_rate:.4f} direct_tags={direct_rate:.4f} dual_candidates={dual_rate:.4f} graph={len(graph['nodes'])}/{len(graph['edges'])}")
    if status!="PASS":
        print("FAILED_GATES="+json.dumps([k for k,v in gates.items() if not v]))
    return 0 if status=="PASS" else 1

if __name__=="__main__":
    raise SystemExit(main())
