#!/usr/bin/env python3
from __future__ import annotations

import argparse
import gzip
import hashlib
import importlib.util
import json
import random
import re
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
V05_PATH = ROOT / "scripts" / "corpus_dualize_v0_5.py"
SPEC = importlib.util.spec_from_file_location("mapeogeo_v05", V05_PATH)
v05 = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(v05)

SEED = 20260915


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def compile_bank(bank: dict[str, tuple[str, ...]]) -> dict[str, tuple[re.Pattern, ...]]:
    return {k: tuple(re.compile(p, re.IGNORECASE) for p in ps) for k, ps in bank.items()}

# EO and GEO banks are deliberately authored independently. There is no
# concept->EO/GEO crosswalk in this stage and no chapter prior in pass metrics.
EO_BANK = compile_bank({
    "EO_ALGEBRA_COMPOSITION": (r"\bgroup\b", r"\bring\b", r"\bfield\b", r"\bhomomorph", r"\bisomorph", r"\bmodule\b", r"\bideal\b", r"\bpolynomial\b", r"\boperation\b"),
    "EO_LINEAR_TRANSFORM": (r"\blinear\b", r"\bmatrix\b", r"\bmatrices\b", r"\bvector\b", r"\bbasis\b", r"\brank\b", r"\bkernel\b", r"\bimage\b", r"\bprojection\b"),
    "EO_FACTORIZATION": (r"\bfactorization\b", r"\bdecomposition\b", r"\bQR\b", r"\bLU\b", r"\bCholesky\b", r"\bSVD\b", r"\bsingular value\b"),
    "EO_SPECTRAL": (r"\beigen", r"\bspectrum\b", r"\bspectral\b", r"\binvariant direction\b"),
    "EO_SCALAR_INVARIANT": (r"\bdeterminant\b", r"\bdet\s*\(", r"\boriented volume\b"),
    "EO_ROTATION_ACTION": (r"\brotation\b", r"\bquaternion\b", r"\bSO\s*\(\s*3\s*\)", r"\bisometr"),
    "EO_MULTILINEAR": (r"\btensor\b", r"\bexterior\b", r"\bwedge\b", r"\bbilinear\b", r"\bquadratic form\b"),
    "EO_DIFFERENTIAL": (r"\bderivative\b", r"\bdifferential\b", r"\bJacobian\b", r"\bgradient\b", r"\bHessian\b", r"\bNewton\b"),
    "EO_OPTIMIZATION": (r"\boptimi", r"\bminimi", r"\bmaximi", r"\blinear program", r"\bsimplex\b", r"\bregression\b", r"\bridge\b", r"\blasso\b", r"\bADMM\b"),
    "EO_DUAL_ADJOINT": (r"\bdual\b", r"\badjoint\b", r"\btranspose\b", r"\bpolar\b"),
    "EO_KERNEL_GRAM": (r"\bpositive definite\b", r"\bkernel\b", r"\bGram\b", r"\bGaussian\b"),
    "EO_GRAPH_OPERATOR": (r"\bgraph Laplacian\b", r"\bLaplacian\b", r"\badjacency\b", r"\bincidence\b"),
    "EO_TOPOLOGICAL_MAP": (r"\bcontinuous\b", r"\bhomeomorph", r"\bembedding\b"),
    "EO_CONVEX_OPERATOR": (r"\bconvex combination\b", r"\bconvex\b", r"\bcone\b", r"\bpolyhed"),
})

GEO_BANK = compile_bank({
    "GEO_ACTION_RELATION": (r"\bgroup\b", r"\bsubgroup\b", r"\bcoset\b", r"\borbit\b", r"\baction\b", r"\brelation\b", r"\bhomomorph"),
    "GEO_SUBSPACE": (r"\bvector space\b", r"\bsubspace\b", r"\bspan\b", r"\bbasis\b", r"\bkernel\b", r"\bimage\b", r"\bdirect sum\b", r"\bprojection\b"),
    "GEO_METRIC_ANGLE": (r"\bnorm\b", r"\bdistance\b", r"\bmetric\b", r"\binner product\b", r"\borthogonal", r"\borthonormal", r"\bangle\b", r"\bunit sphere\b"),
    "GEO_ORIENTED_VOLUME": (r"\bdeterminant\b", r"\bvolume\b", r"\borientation\b", r"\bexterior\b", r"\bwedge\b"),
    "GEO_ROTATION_ISOMETRY": (r"\brotation\b", r"\bquaternion\b", r"\bisometr", r"\bSO\s*\(\s*3\s*\)", r"\bunitary\b"),
    "GEO_GRAPH": (r"\bgraph\b", r"\bvertex\b", r"\bedge\b", r"\bpath\b", r"\bLaplacian\b", r"\bincidence\b"),
    "GEO_PRINCIPAL_AXIS": (r"\beigen", r"\bsingular vector\b", r"\bsingular value\b", r"\bprincipal\b", r"\binvariant subspace\b", r"\binvariant direction\b"),
    "GEO_AFFINE_PROJECTIVE": (r"\baffine\b", r"\bprojective\b", r"\bhomogeneous coordinate"),
    "GEO_TOPOLOGY": (r"\btopolog", r"\bopen set\b", r"\bclosed set\b", r"\bneighbou?rhood\b", r"\bcompact\b", r"\bconnected\b", r"\bhomeomorph"),
    "GEO_TANGENT_LOCAL": (r"\btangent\b", r"\bderivative\b", r"\bdifferential\b", r"\bgradient\b", r"\bHessian\b", r"\bmanifold\b"),
    "GEO_CONVEX_POLYHEDRAL": (r"\bconvex\b", r"\bcone\b", r"\bpolyhed", r"\bhyperplane\b", r"\bhalf-?space\b", r"\bprimal\b", r"\bdual\b"),
    "GEO_HILBERT_PROJECTION": (r"\bHilbert\b", r"\borthogonal projection\b", r"\bnearest point\b", r"\borthogonal complement\b"),
    "GEO_SIMILARITY_KERNEL": (r"\bkernel\b", r"\bGaussian\b", r"\bsimilarity\b", r"\bfeature space\b", r"\bGram\b"),
    "GEO_MARGIN": (r"\bmargin\b", r"\bsupport vector\b", r"\bseparator\b", r"\bseparating hyperplane\b"),
    "GEO_OBJECTIVE_LANDSCAPE": (r"\bminimum\b", r"\bmaximum\b", r"\bextrem", r"\bcritical point\b", r"\boptimi"),
    "GEO_TENSOR_ORIENTED_SUBSPACE": (r"\btensor\b", r"\bexterior\b", r"\bwedge\b", r"\bmultilinear\b"),
    "GEO_MODULE_ACTION": (r"\bmodule\b", r"\bmodule action\b", r"\bscalar multiplication\b"),
})


def detect(bank: dict[str, tuple[re.Pattern, ...]], text: str) -> list[str]:
    return sorted(k for k, ps in bank.items() if any(p.search(text) for p in ps))


def statement_text_candidates(lines: list[dict]) -> list[dict]:
    starts=v05.declaration_starts(lines); out=[]
    for pos,st in enumerate(starts):
        end=starts[pos+1].line_index if pos+1<len(starts) else len(lines)
        records=lines[st.line_index:end]
        segment=v05.normalize_text("\n".join(r["text"] for r in records))
        proof_offset=None
        for j,r in enumerate(records):
            if v05.PROOF_RE.match(r["text"]): proof_offset=j; break
        statement_records=records[:proof_offset] if proof_offset is not None else records
        statement=v05.normalize_text("\n".join(r["text"] for r in statement_records))
        out.append({"kind":st.kind,"number":st.number,"source_segment_sha256":sha256_text(segment),"statement_text":statement,"statement_sha256":sha256_text(statement),"statement_chars":len(statement)})
    return out


def add_independent_profiles(decls: list[dict], lines: list[dict]) -> list[dict]:
    by_hash={c["source_segment_sha256"]:c for c in statement_text_candidates(lines)}
    out=[]
    for d in decls:
        c=by_hash.get(d["source_segment_sha256"])
        if not c:
            raise RuntimeError(f"statement span unavailable for {d['kind']} {d['number']}")
        eo=detect(EO_BANK,c["statement_text"]); geo=detect(GEO_BANK,c["statement_text"])
        status="DUAL_DIRECT" if eo and geo else ("EO_ONLY_DIRECT" if eo else ("GEO_ONLY_DIRECT" if geo else "NO_DIRECT_VIEW"))
        out.append({**d,"independent_profile":{"statement_sha256":c["statement_sha256"],"statement_chars":c["statement_chars"],"eo_direct_families":eo,"geo_direct_families":geo,"direct_status":status}})
    return out


def jaccard(a:set[str],b:set[str])->float:
    if not a and not b: return 1.0
    if not a or not b: return 0.0
    return len(a&b)/len(a|b)


def dependency_similarity(graph:dict, profiles:list[dict], permutations:int=500)->dict:
    rng=random.Random(SEED)
    by_id={v05.decl_node_id(d["kind"],d["number"]):d for d in profiles}
    by_ch=defaultdict(list)
    for nid,d in by_id.items(): by_ch[d["chapter"]].append(nid)
    deps=[]
    for e in graph.get("edges",[]):
        if e.get("type")=="DEPENDS_ON" and e.get("source") in by_id and e.get("target") in by_id:
            deps.append((e["source"],e["target"]))
    def fam(nid,key): return set(by_id[nid]["independent_profile"][key])
    def actual_mean(key):
        vals=[jaccard(fam(s,key),fam(t,key)) for s,t in deps if fam(s,key) and fam(t,key)]
        return sum(vals)/len(vals) if vals else 0.0, len(vals)
    def random_means(key):
        means=[]
        for _ in range(permutations):
            vals=[]
            for s,t in deps:
                pool=[x for x in by_ch.get(by_id[t]["chapter"],[]) if x not in {s,t}]
                if not pool: pool=[x for x in by_id if x not in {s,t}]
                if not pool: continue
                rt=rng.choice(pool)
                if fam(s,key) and fam(rt,key): vals.append(jaccard(fam(s,key),fam(rt,key)))
            means.append(sum(vals)/len(vals) if vals else 0.0)
        return means
    result={"dependency_edges":len(deps),"permutations":permutations}
    for name,key in [("eo","eo_direct_families"),("geo","geo_direct_families")]:
        actual,n=actual_mean(key); rms=random_means(key); rm=sum(rms)/len(rms) if rms else 0.0
        p=(1+sum(x>=actual for x in rms))/(1+len(rms)) if rms else 1.0
        result[name]={"actual_mean_jaccard":actual,"actual_edges_with_evidence":n,"matched_random_mean_jaccard":rm,"delta":actual-rm,"one_sided_permutation_p":p}
    return result


def fixture_recovery(base:dict)->dict:
    nodes={n["id"]:n for n in base.get("nodes",[])}; fixtures=[n for n in nodes.values() if n.get("id","").startswith("obj:test:")]
    recovered=[]; missing=[]
    for f in fixtures:
        bits=[f.get("label","")]
        for e in base.get("edges",[]):
            if e.get("type")=="REPRESENTS" and e.get("target")==f["id"] and e.get("source") in nodes:
                bits.append(nodes[e["source"]].get("attributes",{}).get("representation",""))
        text=" ".join(bits); eo=detect(EO_BANK,text); geo=detect(GEO_BANK,text)
        (recovered if eo and geo else missing).append(f["id"])
    return {"total":len(fixtures),"recovered":len(recovered),"missing":missing}


def main()->int:
    ap=argparse.ArgumentParser(description="MAPEOGEO v0.6 independent EO/GEO statement-view audit")
    ap.add_argument("pdf",type=Path); ap.add_argument("--base-graph",type=Path,required=True); ap.add_argument("--out-dir",type=Path,required=True)
    ap.add_argument("--min-declarations",type=int,default=1355); ap.add_argument("--min-definitions",type=int,default=463); ap.add_argument("--min-proofs",type=int,default=609); ap.add_argument("--min-resolved-deps",type=int,default=638); ap.add_argument("--max-unresolved-rate",type=float,default=0.0938)
    ap.add_argument("--min-eo-direct",type=float,default=0.70); ap.add_argument("--min-geo-direct",type=float,default=0.70); ap.add_argument("--min-dual-direct",type=float,default=0.60); ap.add_argument("--max-no-direct",type=float,default=0.15); ap.add_argument("--max-permutation-p",type=float,default=0.05)
    args=ap.parse_args(); args.out_dir.mkdir(parents=True,exist_ok=True)
    lines,pdf_meta=v05.extract_line_stream(args.pdf); raw=v05.find_declarations(lines); decls,dropped=v05.dedupe_declarations(raw); prof=add_independent_profiles(decls,lines)
    base=v05.load_json_any(args.base_graph); graph,deps=v05.merge_into_graph(base,decls); graph["schema_version"]="0.6.0"; graph["graph_id"]="MAPEOGEO-GALLIER-QUAINTANCE-V0.6"
    nodes,edges=graph["nodes"],graph["edges"]; nids={n["id"] for n in nodes}; eids={e["id"] for e in edges}
    # Independent family nodes and evidence edges.
    for fam in sorted(EO_BANK):
        nid=f"ontology:independent-eo:{fam.lower()}"
        if nid not in nids: nodes.append({"id":nid,"type":"OPERATOR","label":fam,"view":"EO","attributes":{"ontology":"MAPEOGEO_INDEPENDENT_EO_V0_6"}}); nids.add(nid)
    for fam in sorted(GEO_BANK):
        nid=f"ontology:independent-geo:{fam.lower()}"
        if nid not in nids: nodes.append({"id":nid,"type":"OPERATOR","label":fam,"view":"GEO","attributes":{"ontology":"MAPEOGEO_INDEPENDENT_GEO_V0_6"}}); nids.add(nid)
    by_node={v05.decl_node_id(d["kind"],d["number"]):d for d in prof}
    node_map={n["id"]:n for n in nodes}
    for nid,d in by_node.items():
        node_map[nid].setdefault("attributes",{})["independent_profile"]={k:v for k,v in d["independent_profile"].items() if k!="statement_text"}
        for fam in d["independent_profile"]["eo_direct_families"]:
            eid=f"e:independent:eo:{d['kind'].lower()}:{d['number'].replace('.','_')}:{fam.lower()}"
            if eid not in eids: edges.append({"id":eid,"type":"INDEPENDENT_EO_EVIDENCE","source":nid,"target":f"ontology:independent-eo:{fam.lower()}","attributes":{"evidence":"STATEMENT_DIRECT"}}); eids.add(eid)
        for fam in d["independent_profile"]["geo_direct_families"]:
            eid=f"e:independent:geo:{d['kind'].lower()}:{d['number'].replace('.','_')}:{fam.lower()}"
            if eid not in eids: edges.append({"id":eid,"type":"INDEPENDENT_GEO_EVIDENCE","source":nid,"target":f"ontology:independent-geo:{fam.lower()}","attributes":{"evidence":"STATEMENT_DIRECT"}}); eids.add(eid)
    n=len(prof); eo_n=sum(bool(d["independent_profile"]["eo_direct_families"]) for d in prof); geo_n=sum(bool(d["independent_profile"]["geo_direct_families"]) for d in prof); dual_n=sum(d["independent_profile"]["direct_status"]=="DUAL_DIRECT" for d in prof); none_n=sum(d["independent_profile"]["direct_status"]=="NO_DIRECT_VIEW" for d in prof)
    kinds=Counter(d["kind"] for d in prof); proofs=sum(d["proof_present"] for d in prof); xrefs=sum(len(d["proof_references"]) for d in prof); unresolved_rate=deps["unresolved_dependency_references"]/xrefs if xrefs else 0.0
    fixture=fixture_recovery(base); sim=dependency_similarity(graph,prof,permutations=500); audit=v05.audit_graph(graph)
    gates={
        "declarations_stable":n>=args.min_declarations,"definitions_stable":kinds.get("Definition",0)>=args.min_definitions,"proofs_stable":proofs>=args.min_proofs,"resolved_dependencies_stable":deps["resolved_dependency_references"]>=args.min_resolved_deps,"unresolved_rate_stable":unresolved_rate<=args.max_unresolved_rate,
        "eo_statement_direct_coverage":eo_n/n>=args.min_eo_direct,"geo_statement_direct_coverage":geo_n/n>=args.min_geo_direct,"independent_dual_statement_coverage":dual_n/n>=args.min_dual_direct,"no_direct_view_rate":none_n/n<=args.max_no_direct,
        "v0_3_fixture_independent_recovery":fixture["total"]==20 and fixture["recovered"]==20,
        "eo_dependency_alignment":sim["eo"]["delta"]>0 and sim["eo"]["one_sided_permutation_p"]<=args.max_permutation_p,
        "geo_dependency_alignment":sim["geo"]["delta"]>0 and sim["geo"]["one_sided_permutation_p"]<=args.max_permutation_p,
        "unique_node_ids":audit["unique_node_ids"],"unique_edge_ids":audit["unique_edge_ids"],"all_edge_endpoints_exist":audit["all_edge_endpoints_exist"],"copyright_payload_policy":audit["no_copyright_payload_fields"],
    }
    status="PASS" if all(gates.values()) else "FAIL"
    safe=[{"kind":d["kind"],"number":d["number"],"chapter":d["chapter"],"pdf_page_start":d["pdf_page_start"],"pdf_page_end":d["pdf_page_end"],"source_segment_sha256":d["source_segment_sha256"],"statement_sha256":d["independent_profile"]["statement_sha256"],"statement_chars":d["independent_profile"]["statement_chars"],"proof_present":d["proof_present"],"eo_direct_families":d["independent_profile"]["eo_direct_families"],"geo_direct_families":d["independent_profile"]["geo_direct_families"],"direct_status":d["independent_profile"]["direct_status"]} for d in prof]
    report={"audit_id":"MAPEOGEO-INDEPENDENT-DUAL-VIEW-V0.6","status":status,"source":{"url":v05.SOURCE_URL,"redistributed":False,"copyright_payload_policy":"HASHED_STATEMENT_METADATA_ONLY",**pdf_meta},"extraction":{"declarations":n,"declarations_by_kind":dict(sorted(kinds.items())),"proof_blocks":proofs,"proof_cross_references":xrefs},"dependencies":{"resolved":deps["resolved_dependency_references"],"unresolved":deps["unresolved_dependency_references"],"unresolved_rate":unresolved_rate},"independent_views":{"eo_direct":eo_n,"eo_direct_coverage":eo_n/n,"geo_direct":geo_n,"geo_direct_coverage":geo_n/n,"dual_direct":dual_n,"dual_direct_coverage":dual_n/n,"no_direct_view":none_n,"no_direct_view_rate":none_n/n,"fixture_recovery":fixture,"derivation":"EO and GEO pattern banks are independent; pass metrics use statement-only spans and no chapter priors."},"dependency_alignment":sim,"graph":{"nodes":len(nodes),"edges":len(edges),"audit":audit},"gates":gates,"claim_boundary":{"supported":["Independent EO and GEO evidence can be recovered directly from theorem/definition statement spans at corpus scale.","Proof-linked declarations can be tested for within-view structural alignment against chapter-matched random controls."],"not_supported_yet":["Executable theorem-level EO/GEO equivalence for all declarations.","Semantic precision of every family assignment.","Universal mathematical closure or Lean proof verification."]}}
    v05.save_json(args.out_dir/"independent_dual_view_report.json",report); v05.save_json(args.out_dir/"independent_statement_profiles.json",safe); v05.save_json(args.out_dir/"mapeogeo_independent_graph.json",graph)
    summary=["# MAPEOGEO Independent Dual-View Audit v0.6","",f"**Status:** {status}","",f"- Declarations: {n}",f"- EO statement-direct coverage: {eo_n/n:.2%}",f"- GEO statement-direct coverage: {geo_n/n:.2%}",f"- Independent dual statement-direct coverage: {dual_n/n:.2%}",f"- No-direct-view rate: {none_n/n:.2%}",f"- EO proof-edge alignment delta: {sim['eo']['delta']:.4f} (p={sim['eo']['one_sided_permutation_p']:.4f})",f"- GEO proof-edge alignment delta: {sim['geo']['delta']:.4f} (p={sim['geo']['one_sided_permutation_p']:.4f})",f"- v0.3 fixture independent recovery: {fixture['recovered']} / {fixture['total']}",f"- Graph: {len(nodes)} nodes / {len(edges)} edges","","Pass metrics use statement-only source spans, independent EO/GEO detectors, and no chapter priors. Source prose is not persisted."]
    (args.out_dir/"V0_6_SUMMARY.md").write_text("\n".join(summary)+"\n",encoding="utf-8")
    print(f"MAPEOGEO_V0_6: {status} declarations={n} eo={eo_n/n:.4f} geo={geo_n/n:.4f} dual={dual_n/n:.4f} none={none_n/n:.4f} eo_delta={sim['eo']['delta']:.4f} eo_p={sim['eo']['one_sided_permutation_p']:.4f} geo_delta={sim['geo']['delta']:.4f} geo_p={sim['geo']['one_sided_permutation_p']:.4f} graph={len(nodes)}/{len(edges)}")
    if status!="PASS": print("FAILED_GATES="+json.dumps([k for k,v in gates.items() if not v]))
    return 0 if status=="PASS" else 1

if __name__=="__main__": raise SystemExit(main())
