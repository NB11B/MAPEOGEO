#!/usr/bin/env python3
from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Iterable

import fitz  # PyMuPDF

SOURCE_URL = "https://www.cis.upenn.edu/~jean/math-deep.pdf"
SOURCE_TITLE = (
    "Algebra, Topology, Differential Calculus, and Optimization Theory "
    "for Computer Science and Machine Learning"
)
SOURCE_AUTHORS = ["Jean Gallier", "Jocelyn Quaintance"]

CHAPTERS = [
    "Introduction",
    "Groups, Rings, and Fields",
    "Vector Spaces, Bases, Linear Maps",
    "Matrices and Linear Maps",
    "Haar Bases, Haar Wavelets, Hadamard Matrices",
    "Direct Sums",
    "Determinants",
    "Gaussian Elimination, LU, Cholesky, Echelon Form",
    "Vector Norms and Matrix Norms",
    "Iterative Methods for Solving Linear Systems",
    "The Dual Space and Duality",
    "Euclidean Spaces",
    "QR-Decomposition for Arbitrary Matrices",
    "Hermitian Spaces",
    "Eigenvectors and Eigenvalues",
    "Unit Quaternions and Rotations in SO(3)",
    "Spectral Theorems",
    "Computing Eigenvalues and Eigenvectors",
    "Introduction to The Finite Elements Method",
    "Graphs and Graph Laplacians; Basic Facts",
    "Spectral Graph Drawing",
    "Singular Value Decomposition and Polar Form",
    "Applications of SVD and Pseudo-Inverses",
    "Basics of Affine Geometry",
    "Embedding an Affine Space in a Vector Space",
    "Basics of Projective Geometry",
    "The Cartan-Dieudonne Theorem",
    "Isometries of Hermitian Spaces",
    "The Geometry of Bilinear Forms; Witt's Theorem",
    "Polynomials, Ideals and PID's",
    "Annihilating Polynomials; Primary Decomposition",
    "UFD's, Noetherian Rings, Hilbert's Basis Theorem",
    "Tensor Algebras",
    "Exterior Tensor Powers and Exterior Algebras",
    "Introduction to Modules; Modules over a PID",
    "Normal Forms; The Rational Canonical Form",
    "Topology",
    "A Detour On Fractals",
    "Differential Calculus",
    "Extrema of Real-Valued Functions",
    "Newton's Method and Its Generalizations",
    "Quadratic Optimization Problems",
    "Schur Complements and Applications",
    "Convex Sets, Cones, H-Polyhedra",
    "Linear Programs",
    "The Simplex Algorithm",
    "Linear Programming and Duality",
    "Basics of Hilbert Spaces",
    "General Results of Optimization Theory",
    "Introduction to Nonlinear Optimization",
    "Subgradients and Subdifferentials",
    "Dual Ascent Methods; ADMM",
    "Ridge Regression and Lasso Regression",
    "Positive Definite Kernels",
    "Soft Margin Support Vector Machines",
    "Total Orthogonal Families in Hilbert Spaces",
    "Zorn's Lemma; Some Applications",
]

DECL_KINDS = (
    "Definition",
    "Proposition",
    "Theorem",
    "Lemma",
    "Corollary",
    "Claim",
    "Fact",
)
DECL_RE = re.compile(
    rf"^\s*(?P<kind>{'|'.join(DECL_KINDS)})\s+"
    r"(?P<number>\d+(?:\.\d+)+)\b",
    re.IGNORECASE,
)
PROOF_RE = re.compile(r"^\s*Proof\s*[\.:]?\s*", re.IGNORECASE)
REF_RE = re.compile(
    rf"\b(?P<kind>{'|'.join(DECL_KINDS)})\s+"
    r"(?P<number>\d+(?:\.\d+)+)\b",
    re.IGNORECASE,
)


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_text(text: str) -> str:
    return sha256_bytes(text.encode("utf-8"))


def normalize_text(text: str) -> str:
    text = text.replace("\u00ad", "")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def canonical_kind(kind: str) -> str:
    low = kind.lower()
    for candidate in DECL_KINDS:
        if candidate.lower() == low:
            return candidate
    return kind.title()


def decl_key(kind: str, number: str) -> tuple[str, str]:
    return canonical_kind(kind).lower(), number


def decl_node_id(kind: str, number: str) -> str:
    return f"srcdecl:{canonical_kind(kind).lower()}:{number.replace('.', '_')}"


def proof_node_id(kind: str, number: str) -> str:
    return f"proof:{canonical_kind(kind).lower()}:{number.replace('.', '_')}"


def load_json_any(path: Path) -> dict:
    if path.suffix == ".gz":
        with gzip.open(path, "rt", encoding="utf-8") as f:
            return json.load(f)
    return json.loads(path.read_text(encoding="utf-8"))


def save_json(path: Path, obj: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, sort_keys=False), encoding="utf-8")


def extract_line_stream(pdf_path: Path) -> tuple[list[dict], dict]:
    pdf_bytes = pdf_path.read_bytes()
    doc = fitz.open(pdf_path)
    lines: list[dict] = []
    nonempty_pages = 0
    total_chars = 0

    for page_index, page in enumerate(doc):
        text = page.get_text("text", sort=True)
        if text.strip():
            nonempty_pages += 1
        total_chars += len(text)
        for local_line, raw in enumerate(text.splitlines(), start=1):
            line = normalize_text(raw)
            if not line:
                continue
            lines.append(
                {
                    "pdf_page": page_index + 1,
                    "local_line": local_line,
                    "text": line,
                }
            )

    metadata = {
        "pdf_sha256": sha256_bytes(pdf_bytes),
        "pdf_size_bytes": len(pdf_bytes),
        "pdf_pages": doc.page_count,
        "nonempty_pages": nonempty_pages,
        "extracted_nonempty_lines": len(lines),
        "extracted_characters": total_chars,
    }
    doc.close()
    return lines, metadata


def find_declarations(lines: list[dict]) -> list[dict]:
    starts: list[tuple[int, re.Match[str]]] = []
    for i, rec in enumerate(lines):
        m = DECL_RE.match(rec["text"])
        if m:
            starts.append((i, m))

    declarations: list[dict] = []
    for start_pos, (line_index, match) in enumerate(starts):
        next_index = starts[start_pos + 1][0] if start_pos + 1 < len(starts) else len(lines)
        segment_records = lines[line_index:next_index]
        segment_text = normalize_text("\n".join(r["text"] for r in segment_records))

        kind = canonical_kind(match.group("kind"))
        number = match.group("number")
        parts = number.split(".")
        chapter = int(parts[0]) if parts and parts[0].isdigit() else None
        if chapter is not None and not (1 <= chapter <= len(CHAPTERS)):
            chapter = None

        proof_offset = None
        for j, rec in enumerate(segment_records):
            if PROOF_RE.match(rec["text"]):
                proof_offset = j
                break

        proof_text = ""
        proof_refs: list[dict] = []
        if proof_offset is not None:
            proof_text = normalize_text("\n".join(r["text"] for r in segment_records[proof_offset:]))
            seen_refs: set[tuple[str, str]] = set()
            for rm in REF_RE.finditer(proof_text):
                ref_kind = canonical_kind(rm.group("kind"))
                ref_number = rm.group("number")
                if (ref_kind.lower(), ref_number) == (kind.lower(), number):
                    continue
                key = (ref_kind.lower(), ref_number)
                if key in seen_refs:
                    continue
                seen_refs.add(key)
                proof_refs.append({"kind": ref_kind, "number": ref_number})

        declarations.append(
            {
                "kind": kind,
                "number": number,
                "chapter": chapter,
                "chapter_title": CHAPTERS[chapter - 1] if chapter else None,
                "pdf_page_start": segment_records[0]["pdf_page"],
                "pdf_page_end": segment_records[-1]["pdf_page"],
                "source_segment_sha256": sha256_text(segment_text),
                "source_segment_chars": len(segment_text),
                "proof_present": proof_offset is not None,
                "proof_sha256": sha256_text(proof_text) if proof_text else None,
                "proof_chars": len(proof_text),
                "proof_references": proof_refs,
            }
        )
    return declarations


def dedupe_declarations(declarations: list[dict]) -> tuple[list[dict], list[dict]]:
    """Prefer declarations found later when duplicate numbered headings occur.

    Duplicate matches can occur in front matter, summaries, or repeated headers. The
    semantic identity is (kind, number). We keep the candidate with the larger source
    segment and record every dropped candidate in the audit ledger.
    """
    grouped: dict[tuple[str, str], list[dict]] = defaultdict(list)
    for d in declarations:
        grouped[decl_key(d["kind"], d["number"])].append(d)

    kept: list[dict] = []
    dropped: list[dict] = []
    for key, candidates in sorted(grouped.items(), key=lambda kv: (int(kv[0][1].split(".")[0]), kv[0][1], kv[0][0])):
        if len(candidates) == 1:
            kept.append(candidates[0])
            continue
        winner = max(
            candidates,
            key=lambda d: (d["source_segment_chars"], d["pdf_page_start"]),
        )
        kept.append(winner)
        for d in candidates:
            if d is not winner:
                dropped.append(
                    {
                        "kind": d["kind"],
                        "number": d["number"],
                        "pdf_page_start": d["pdf_page_start"],
                        "pdf_page_end": d["pdf_page_end"],
                        "source_segment_sha256": d["source_segment_sha256"],
                        "reason": "duplicate_semantic_key",
                        "winner_pdf_page_start": winner["pdf_page_start"],
                    }
                )
    kept.sort(key=lambda d: (d["chapter"] or 999, tuple(int(x) for x in d["number"].split(".")), d["kind"]))
    return kept, dropped


def ensure_source_scaffold(graph: dict) -> tuple[dict[int, str], str]:
    nodes = graph.setdefault("nodes", [])
    edges = graph.setdefault("edges", [])
    ids = {n.get("id") for n in nodes}
    edge_ids = {e.get("id") for e in edges}

    book_id = "src:book"
    if book_id not in ids:
        nodes.append(
            {
                "id": book_id,
                "type": "SOURCE",
                "label": SOURCE_TITLE,
                "attributes": {"url": SOURCE_URL, "authors": SOURCE_AUTHORS},
            }
        )
        ids.add(book_id)

    chapter_ids: dict[int, str] = {}
    for i, title in enumerate(CHAPTERS, start=1):
        cid = f"src:chapter:{i:02d}"
        chapter_ids[i] = cid
        if cid not in ids:
            nodes.append(
                {
                    "id": cid,
                    "type": "SOURCE",
                    "label": f"Chapter {i}: {title}",
                    "attributes": {"chapter_number": i, "title": title},
                }
            )
            ids.add(cid)
        eid = f"e:book:chapter:{i:02d}"
        if eid not in edge_ids:
            edges.append(
                {
                    "id": eid,
                    "type": "CONTAINS",
                    "source": book_id,
                    "target": cid,
                    "ordinal": i,
                }
            )
            edge_ids.add(eid)
    return chapter_ids, book_id


def merge_declarations_into_graph(base_graph: dict, declarations: list[dict]) -> tuple[dict, dict]:
    graph = json.loads(json.dumps(base_graph))
    graph["graph_id"] = "MAPEOGEO-MATH-DEEP-SOURCE-INGEST-V0.4"
    graph["schema_version"] = "0.4.0"
    graph.setdefault("required_views", ["EO", "GEO"])

    chapter_ids, _ = ensure_source_scaffold(graph)
    nodes: list[dict] = graph["nodes"]
    edges: list[dict] = graph["edges"]
    existing_node_ids = {n["id"] for n in nodes}
    existing_edge_ids = {e["id"] for e in edges}

    declaration_index = {decl_key(d["kind"], d["number"]): d for d in declarations}
    key_to_node: dict[tuple[str, str], str] = {}

    for d in declarations:
        nid = decl_node_id(d["kind"], d["number"])
        key_to_node[decl_key(d["kind"], d["number"])] = nid
        if nid not in existing_node_ids:
            nodes.append(
                {
                    "id": nid,
                    "type": "STATEMENT",
                    "label": f"{d['kind']} {d['number']}",
                    "attributes": {
                        "source": SOURCE_URL,
                        "declaration_kind": d["kind"],
                        "number": d["number"],
                        "chapter": d["chapter"],
                        "chapter_title": d["chapter_title"],
                        "pdf_page_start": d["pdf_page_start"],
                        "pdf_page_end": d["pdf_page_end"],
                        "source_segment_sha256": d["source_segment_sha256"],
                        "source_segment_chars": d["source_segment_chars"],
                        "proof_present": d["proof_present"],
                        "proof_sha256": d["proof_sha256"],
                        "proof_chars": d["proof_chars"],
                        "dualization_status": "UNCLASSIFIED",
                        "copyright_payload": "METADATA_HASHES_ONLY",
                    },
                }
            )
            existing_node_ids.add(nid)

        if d["chapter"]:
            eid = f"e:srcdecl:{d['kind'].lower()}:{d['number'].replace('.', '_')}:chapter"
            if eid not in existing_edge_ids:
                edges.append(
                    {
                        "id": eid,
                        "type": "SOURCED_FROM",
                        "source": nid,
                        "target": chapter_ids[d["chapter"]],
                    }
                )
                existing_edge_ids.add(eid)

        if d["proof_present"]:
            pid = proof_node_id(d["kind"], d["number"])
            if pid not in existing_node_ids:
                nodes.append(
                    {
                        "id": pid,
                        "type": "PROOF_STEP",
                        "label": f"Proof block for {d['kind']} {d['number']}",
                        "attributes": {
                            "source": SOURCE_URL,
                            "proof_sha256": d["proof_sha256"],
                            "proof_chars": d["proof_chars"],
                            "copyright_payload": "METADATA_HASHES_ONLY",
                        },
                    }
                )
                existing_node_ids.add(pid)
            eid = f"e:proof:{d['kind'].lower()}:{d['number'].replace('.', '_')}:produces"
            if eid not in existing_edge_ids:
                edges.append(
                    {
                        "id": eid,
                        "type": "PRODUCES",
                        "source": pid,
                        "target": nid,
                    }
                )
                existing_edge_ids.add(eid)

    resolved = 0
    unresolved: list[dict] = []
    dependency_seen: set[tuple[str, str]] = set()
    for d in declarations:
        if not d["proof_present"]:
            continue
        source_key = decl_key(d["kind"], d["number"])
        source_node = key_to_node[source_key]
        proof_node = proof_node_id(d["kind"], d["number"])
        for ref in d["proof_references"]:
            target_key = decl_key(ref["kind"], ref["number"])
            target_node = key_to_node.get(target_key)
            if target_node:
                dep_key = (source_node, target_node)
                if dep_key in dependency_seen:
                    continue
                dependency_seen.add(dep_key)
                eid = (
                    f"e:proofref:{d['kind'].lower()}:{d['number'].replace('.', '_')}:"
                    f"{ref['kind'].lower()}:{ref['number'].replace('.', '_')}"
                )
                if eid not in existing_edge_ids:
                    edges.append(
                        {
                            "id": eid,
                            "type": "DEPENDS_ON",
                            "source": source_node,
                            "target": target_node,
                            "attributes": {
                                "evidence": "SOURCE_PROOF_CROSS_REFERENCE",
                                "proof_node": proof_node,
                                "reference_kind": ref["kind"],
                                "reference_number": ref["number"],
                            },
                        }
                    )
                    existing_edge_ids.add(eid)
                peid = eid + ":premise"
                if peid not in existing_edge_ids:
                    edges.append(
                        {
                            "id": peid,
                            "type": "PREMISE",
                            "source": target_node,
                            "target": proof_node,
                            "attributes": {
                                "evidence": "SOURCE_PROOF_CROSS_REFERENCE",
                            },
                        }
                    )
                    existing_edge_ids.add(peid)
                resolved += 1
            else:
                unresolved.append(
                    {
                        "source_kind": d["kind"],
                        "source_number": d["number"],
                        "target_kind": ref["kind"],
                        "target_number": ref["number"],
                    }
                )

    stats = {
        "resolved_dependency_references": resolved,
        "unresolved_dependency_references": len(unresolved),
        "unresolved_references": unresolved,
    }
    return graph, stats


def audit_graph(graph: dict) -> dict:
    nodes = graph.get("nodes", [])
    edges = graph.get("edges", [])
    node_ids = [n.get("id") for n in nodes]
    edge_ids = [e.get("id") for e in edges]
    by_id = {n.get("id"): n for n in nodes}

    forbidden_payload_fields = {"text", "excerpt", "statement_text", "proof_text", "source_text", "body"}
    payload_violations = []
    for n in nodes:
        attrs = n.get("attributes", {})
        bad = forbidden_payload_fields.intersection(attrs)
        if bad:
            payload_violations.append({"id": n.get("id"), "fields": sorted(bad)})

    return {
        "unique_node_ids": len(node_ids) == len(set(node_ids)),
        "unique_edge_ids": len(edge_ids) == len(set(edge_ids)),
        "all_edge_endpoints_exist": all(e.get("source") in by_id and e.get("target") in by_id for e in edges),
        "no_copyright_payload_fields": not payload_violations,
        "payload_violations": payload_violations,
    }


def main() -> int:
    ap = argparse.ArgumentParser(description="Import mathematical declaration/proof metadata from the Gallier-Quaintance source PDF into MAPEOGEO.")
    ap.add_argument("pdf", type=Path)
    ap.add_argument("--base-graph", type=Path, default=None)
    ap.add_argument("--out-dir", type=Path, required=True)
    ap.add_argument("--min-declarations", type=int, default=100)
    ap.add_argument("--min-chapters", type=int, default=30)
    args = ap.parse_args()

    args.out_dir.mkdir(parents=True, exist_ok=True)
    lines, pdf_meta = extract_line_stream(args.pdf)
    raw_decls = find_declarations(lines)
    declarations, dropped = dedupe_declarations(raw_decls)

    if args.base_graph:
        base_graph = load_json_any(args.base_graph)
    else:
        base_graph = {
            "graph_id": "MAPEOGEO-SOURCE-INGEST-BASE",
            "schema_version": "0.4.0",
            "required_views": ["EO", "GEO"],
            "nodes": [],
            "edges": [],
        }

    graph, dep_stats = merge_declarations_into_graph(base_graph, declarations)
    graph_audit = audit_graph(graph)

    kinds = Counter(d["kind"] for d in declarations)
    chapters = sorted({d["chapter"] for d in declarations if d["chapter"]})
    proof_count = sum(bool(d["proof_present"]) for d in declarations)
    proof_ref_count = sum(len(d["proof_references"]) for d in declarations)

    gate_checks = {
        "minimum_declarations": len(declarations) >= args.min_declarations,
        "minimum_chapter_coverage": len(chapters) >= args.min_chapters,
        "pdf_has_text": pdf_meta["nonempty_pages"] > 0 and pdf_meta["extracted_nonempty_lines"] > 0,
        "declarations_have_valid_chapters": all(d["chapter"] is None or 1 <= d["chapter"] <= 57 for d in declarations),
        "graph_unique_node_ids": graph_audit["unique_node_ids"],
        "graph_unique_edge_ids": graph_audit["unique_edge_ids"],
        "graph_endpoints_exist": graph_audit["all_edge_endpoints_exist"],
        "copyright_payload_policy": graph_audit["no_copyright_payload_fields"],
    }
    status = "PASS" if all(gate_checks.values()) else "FAIL"

    report = {
        "ingest_id": "MAPEOGEO-MATH-DEEP-SOURCE-INGEST-V0.4",
        "status": status,
        "source": {
            "title": SOURCE_TITLE,
            "authors": SOURCE_AUTHORS,
            "url": SOURCE_URL,
            "redistributed": False,
            "copyright_payload_policy": "METADATA_HASHES_ONLY",
            **pdf_meta,
        },
        "extraction": {
            "raw_declaration_matches": len(raw_decls),
            "deduplicated_declarations": len(declarations),
            "duplicate_candidates_dropped": len(dropped),
            "chapters_with_declarations": len(chapters),
            "covered_chapters": chapters,
            "proof_blocks_detected": proof_count,
            "proof_cross_references_detected": proof_ref_count,
            "declarations_by_kind": dict(sorted(kinds.items())),
        },
        "dependencies": dep_stats,
        "graph": {
            "nodes": len(graph.get("nodes", [])),
            "edges": len(graph.get("edges", [])),
            "audit": graph_audit,
        },
        "gates": gate_checks,
        "claim_boundary": {
            "supported": [
                "Source-level declarations can be imported as structured graph nodes without storing source prose.",
                "Explicit theorem/proposition references found inside proof blocks can be represented as proof dependency edges.",
                "The source declaration layer can be merged into the existing dual EO/GEO graph without changing the core ontology.",
            ],
            "not_supported_yet": [
                "Semantic EO/GEO classification of every imported declaration.",
                "Formal proof reconstruction from source prose.",
                "Lean proof generation or kernel verification.",
                "Dependency edges not explicitly referenced in source proof text.",
            ],
        },
    }

    safe_declarations = [
        {
            "kind": d["kind"],
            "number": d["number"],
            "chapter": d["chapter"],
            "chapter_title": d["chapter_title"],
            "pdf_page_start": d["pdf_page_start"],
            "pdf_page_end": d["pdf_page_end"],
            "source_segment_sha256": d["source_segment_sha256"],
            "source_segment_chars": d["source_segment_chars"],
            "proof_present": d["proof_present"],
            "proof_sha256": d["proof_sha256"],
            "proof_chars": d["proof_chars"],
            "proof_references": d["proof_references"],
        }
        for d in declarations
    ]

    save_json(args.out_dir / "source_ingest_report.json", report)
    save_json(args.out_dir / "source_declarations.json", safe_declarations)
    save_json(args.out_dir / "duplicate_declaration_audit.json", dropped)
    save_json(args.out_dir / "mapeogeo_source_graph.json", graph)

    summary_lines = [
        "# MAPEOGEO Source Ingestion v0.4",
        "",
        f"**Status:** {status}",
        "",
        f"- PDF pages: {pdf_meta['pdf_pages']}",
        f"- Deduplicated declarations: {len(declarations)}",
        f"- Chapters with declarations: {len(chapters)} / 57",
        f"- Proof blocks detected: {proof_count}",
        f"- Proof cross-references detected: {proof_ref_count}",
        f"- Resolved dependency references: {dep_stats['resolved_dependency_references']}",
        f"- Unresolved dependency references: {dep_stats['unresolved_dependency_references']}",
        f"- Graph nodes: {len(graph.get('nodes', []))}",
        f"- Graph edges: {len(graph.get('edges', []))}",
        "",
        "The source PDF is not redistributed. Generated artifacts contain locators, types, hashes, counts, and graph structure, not source prose.",
    ]
    (args.out_dir / "SOURCE_INGEST_SUMMARY.md").write_text("\n".join(summary_lines) + "\n", encoding="utf-8")

    print(
        f"MAPEOGEO_SOURCE_INGEST: {status} "
        f"pages={pdf_meta['pdf_pages']} declarations={len(declarations)} "
        f"chapters={len(chapters)} proofs={proof_count} "
        f"resolved_deps={dep_stats['resolved_dependency_references']} "
        f"unresolved_deps={dep_stats['unresolved_dependency_references']}"
    )
    return 0 if status == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
