#!/usr/bin/env python3
from __future__ import annotations
import json, math, random
from pathlib import Path
from collections import defaultdict

import numpy as np
import sympy as sp
from scipy.optimize import linprog
from scipy.spatial import ConvexHull

SEED = 20260914
rng = np.random.default_rng(SEED)
random.seed(SEED)

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
DATA.mkdir(parents=True, exist_ok=True)

SOURCE_PDF = "https://www.cis.upenn.edu/~jean/math-deep.pdf"
SOURCE_TITLE = (
    "Algebra, Topology, Differential Calculus, and Optimization Theory "
    "for Computer Science and Machine Learning"
)

chapters = [
    "Introduction",
    "Groups, Rings, and Fields",
    "Vector Spaces, Bases, Linear Maps",
    "Matrices and Linear Maps",
    "Haar Bases, Haar Wavelets, Hadamard Matrices",
    "Direct Sums",
    "Determinants",
    "Gaussian Elimination, LU, Cholesky, Echelon Form",
    "Vector Norms and Matrix Norms",
    "Iterative Methods for Solving Linear Systems",
    "The Dual Space and Duality",
    "Euclidean Spaces",
    "QR-Decomposition for Arbitrary Matrices",
    "Hermitian Spaces",
    "Eigenvectors and Eigenvalues",
    "Unit Quaternions and Rotations in SO(3)",
    "Spectral Theorems",
    "Computing Eigenvalues and Eigenvectors",
    "Introduction to The Finite Elements Method",
    "Graphs and Graph Laplacians; Basic Facts",
    "Spectral Graph Drawing",
    "Singular Value Decomposition and Polar Form",
    "Applications of SVD and Pseudo-Inverses",
    "Basics of Affine Geometry",
    "Embedding an Affine Space in a Vector Space",
    "Basics of Projective Geometry",
    "The Cartan-Dieudonne Theorem",
    "Isometries of Hermitian Spaces",
    "The Geometry of Bilinear Forms; Witt's Theorem",
    "Polynomials, Ideals and PID's",
    "Annihilating Polynomials; Primary Decomposition",
    "UFD's, Noetherian Rings, Hilbert's Basis Theorem",
    "Tensor Algebras",
    "Exterior Tensor Powers and Exterior Algebras",
    "Introduction to Modules; Modules over a PID",
    "Normal Forms; The Rational Canonical Form",
    "Topology",
    "A Detour On Fractals",
    "Differential Calculus",
    "Extrema of Real-Valued Functions",
    "Newton's Method and Its Generalizations",
    "Quadratic Optimization Problems",
    "Schur Complements and Applications",
    "Convex Sets, Cones, H-Polyhedra",
    "Linear Programs",
    "The Simplex Algorithm",
    "Linear Programming and Duality",
    "Basics of Hilbert Spaces",
    "General Results of Optimization Theory",
    "Introduction to Nonlinear Optimization",
    "Subgradients and Subdifferentials",
    "Dual Ascent Methods; ADMM",
    "Ridge Regression and Lasso Regression",
    "Positive Definite Kernels",
    "Soft Margin Support Vector Machines",
    "Total Orthogonal Families in Hilbert Spaces",
    "Zorn's Lemma; Some Applications",
]
assert len(chapters) == 57

rows = []
def rec(case, chapter, checks, passed, max_error, eo, geo, contract, evidence="B"):
    rows.append({
        "case": case, "chapter": chapter, "checks": int(checks),
        "status": "PASS" if passed else "FAIL",
        "max_error": None if max_error is None else float(max_error),
        "eo_view": eo, "geo_view": geo, "contract": contract,
        "evidence_class": evidence,
    })

# 1 — Group composition / Cayley path
checks=bad=0
for n in range(2,30):
    for a in range(n):
        for b in range(n):
            endpoint=a
            for _ in range(b): endpoint=(endpoint+1)%n
            checks+=1; bad += endpoint != (a+b)%n
rec("Cyclic group composition",2,checks,bad==0,0.0,
    "binary group operator a*b","Cayley-graph generator path",
    "operator result equals relational path endpoint")

# 2 — Rank-nullity
checks=bad=0
for _ in range(350):
    m=int(rng.integers(1,9)); n=int(rng.integers(1,9))
    A=sp.Matrix(rng.integers(-5,6,size=(m,n)).tolist())
    r=A.rank(); checks+=1; bad += n != r+(n-r)
rec("Rank-nullity",3,checks,bad==0,0.0,
    "dimension/rank/nullity operators","kernel-image decomposition geometry",
    "dim(domain)=rank+nullity")

# 3 — Determinant / oriented volume
checks=bad=0; mx=0.0
for _ in range(600):
    A=rng.normal(size=(3,3))
    e=abs(float(np.linalg.det(A))-float(np.dot(A[:,0],np.cross(A[:,1],A[:,2]))))
    mx=max(mx,e); checks+=1; bad += e>2e-12
rec("Determinant as oriented volume",7,checks,bad==0,mx,
    "det(A)","oriented volume / triple product",
    "determinant equals oriented volume")

# 4 — QR / orthonormal frame
checks=bad=0; mx=0.0
for _ in range(500):
    m=int(rng.integers(3,9)); n=int(rng.integers(2,min(m,6)+1))
    A=rng.normal(size=(m,n)); Q,R=np.linalg.qr(A,mode="reduced")
    e=max(float(np.max(np.abs(A-Q@R))),float(np.max(np.abs(Q.T@Q-np.eye(n)))))
    mx=max(mx,e); checks+=1; bad += e>5e-12
rec("QR decomposition",13,checks,bad==0,mx,
    "A=QR factorization","coordinates in an orthonormal frame",
    "factorization and frame geometry agree")

# Quaternion helpers
def qmul(q,p):
    w1,x1,y1,z1=q; w2,x2,y2,z2=p
    return np.array([
        w1*w2-x1*x2-y1*y2-z1*z2,
        w1*x2+x1*w2+y1*z2-z1*y2,
        w1*y2-x1*z2+y1*w2+z1*x2,
        w1*z2+x1*y2-y1*x2+z1*w2])
def qconj(q): return np.array([q[0],-q[1],-q[2],-q[3]])
def qrotate(q,v): return qmul(qmul(q,np.array([0.0,*v])),qconj(q))[1:]
def qmatrix(q):
    w,x,y,z=q
    return np.array([
        [1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],
        [2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],
        [2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]])

# 5 — SO(3) matrix / quaternion-rotor
checks=bad=0; mx=0.0
for _ in range(3000):
    q=rng.normal(size=4); q/=np.linalg.norm(q); v=rng.normal(size=3)
    e=float(np.max(np.abs(qmatrix(q)@v-qrotate(q,v))))
    mx=max(mx,e); checks+=1; bad += e>3e-12
rec("SO(3) rotation",16,checks,bad==0,mx,
    "3x3 rotation matrix","unit-quaternion / Spin(3) sandwich",
    "same rotated vector","A/B")

# 6 — Eigenpair / invariant direction
checks=bad=0; mx=0.0
for _ in range(450):
    M=rng.normal(size=(5,5)); A=M+M.T
    vals,vecs=np.linalg.eigh(A)
    for k in range(5):
        e=float(np.max(np.abs(A@vecs[:,k]-vals[k]*vecs[:,k])))
        mx=max(mx,e); checks+=1; bad += e>1e-10
rec("Eigenpairs",15,checks,bad==0,mx,
    "Av=lambda v","invariant directions with scalar stretch",
    "operator eigen-equation equals invariant-direction geometry")

# 7 — Laplacian / incidence geometry
checks=bad=0; mx=0.0
for _ in range(700):
    n=int(rng.integers(2,15)); p=float(rng.uniform(.1,.8))
    A=np.zeros((n,n)); edges=[]
    for i in range(n):
        for j in range(i+1,n):
            if rng.random()<p: A[i,j]=A[j,i]=1.0; edges.append((i,j))
    L=np.diag(A.sum(1))-A; B=np.zeros((n,len(edges)))
    for k,(i,j) in enumerate(edges): B[i,k]=1.0; B[j,k]=-1.0
    e=float(np.max(np.abs(L-B@B.T))); mx=max(mx,e); checks+=1; bad += e>1e-12
rec("Graph Laplacian",20,checks,bad==0,mx,
    "L=D-A","incidence geometry L=B B^T","same Laplacian operator")

# 8 — SVD / principal-axis geometry
checks=bad=0; mx=0.0
for _ in range(450):
    m=int(rng.integers(2,8)); n=int(rng.integers(2,8)); A=rng.normal(size=(m,n))
    U,s,Vt=np.linalg.svd(A,full_matrices=False)
    for k in range(len(s)):
        e=max(float(np.max(np.abs(A@Vt[k]-s[k]*U[:,k]))),
              float(np.max(np.abs(A.T@U[:,k]-s[k]*Vt[k]))))
        mx=max(mx,e); checks+=1; bad += e>2e-10
rec("Singular value decomposition",22,checks,bad==0,mx,
    "A=U Sigma V^T","principal axes and stretches of the image ellipsoid",
    "singular-vector equations match principal-axis geometry")

# 9 — Projective scale equivalence
checks=bad=0; mx=0.0
for _ in range(900):
    H=rng.normal(size=(3,3))
    while abs(np.linalg.det(H))<.1: H=rng.normal(size=(3,3))
    x=rng.normal(size=3)
    while abs(x[2])<.1: x=rng.normal(size=3)
    lam=float(rng.uniform(.2,4.0)); y1=H@x; y2=H@(lam*x)
    if abs(y1[2])<1e-10 or abs(y2[2])<1e-10: continue
    e=float(np.max(np.abs(y1[:2]/y1[2]-y2[:2]/y2[2])))
    mx=max(mx,e); checks+=1; bad += e>1e-10
rec("Projective homogeneous equivalence",26,checks,bad==0,mx,
    "linear action on homogeneous coordinates","projective point as a scale-equivalence class",
    "scaling a representative does not change the projective result")

# 10 — Tensor / Kronecker composition
checks=bad=0; mx=0.0
for _ in range(500):
    A=rng.normal(size=(3,4)); X=rng.normal(size=(4,5)); B=rng.normal(size=(2,5))
    lhs=A@X@B.T
    rhs=(np.kron(B,A)@X.reshape(-1,order="F")).reshape((3,2),order="F")
    e=float(np.max(np.abs(lhs-rhs))); mx=max(mx,e); checks+=1; bad += e>1e-10
rec("Tensor/Kronecker composition",33,checks,bad==0,mx,
    "Kronecker linear operator","tensor-product composition of two maps",
    "vec(A X B^T)=(B kron A)vec(X)")

# 11 — Exterior product / Gram area
checks=bad=0; mx=0.0
for _ in range(1000):
    u=rng.normal(size=3); v=rng.normal(size=3)
    G=np.array([[u@u,u@v],[v@u,v@v]])
    e=abs(float(np.linalg.norm(np.cross(u,v)))-math.sqrt(max(0.0,float(np.linalg.det(G)))))
    mx=max(mx,e); checks+=1; bad += e>2e-10
rec("Exterior product / area",34,checks,bad==0,mx,
    "wedge product u^v","oriented parallelogram area",
    "|u^v|^2=det(Gram(u,v))")

# 12 — Frechet derivative / tangent geometry
def f(x):
    x0,x1,x2=x
    return np.array([np.sin(x0)+x1*x2,np.exp(x1)+x0*x0+.5*x2])
def jac(x):
    x0,x1,x2=x
    return np.array([[np.cos(x0),x2,x1],[2*x0,np.exp(x1),.5]])
checks=bad=0; mx=0.0
for _ in range(450):
    a=rng.normal(scale=.7,size=3); u=rng.normal(size=3); u/=np.linalg.norm(u)
    J=jac(a); ratios=[]
    for s in (1e-1,1e-2,1e-3,1e-4):
        h=s*u; rem=f(a+h)-f(a)-J@h
        ratios.append(float(np.linalg.norm(rem)/np.linalg.norm(h)))
    mx=max(mx,ratios[-1]); checks+=1
    bad += not (np.isfinite(ratios).all() and ratios[-1] < ratios[0]*0.01)
rec("Frechet derivative",39,checks,bad==0,mx,
    "linear operator Df(a)","tangent-linear local geometry",
    "normalized nonlinear remainder contracts toward zero")

# 13 — Newton / tangent intercept
checks=bad=0; mx=0.0
for _ in range(600):
    c=float(rng.uniform(.2,10)); x=float(rng.uniform(.3,5))
    fx=x*x-c; dfx=2*x
    eo=x-fx/dfx; geo=x-fx/dfx
    e=abs(eo-geo); mx=max(mx,e); checks+=1; bad += e>1e-15
rec("Newton step",41,checks,bad==0,mx,
    "x_next=x-f/f'","x-intercept of the tangent line",
    "operator update equals tangent-intersection geometry")

# 14 — Quadratic minimum
checks=bad=0; mx=0.0
for _ in range(400):
    M=rng.normal(size=(5,5)); Q=M.T@M+.5*np.eye(5); b=rng.normal(size=5)
    x=np.linalg.solve(Q,b); e=float(np.max(np.abs(Q@x-b)))
    mx=max(mx,e); checks+=1; bad += e>1e-10
rec("Strict quadratic minimization",42,checks,bad==0,mx,
    "solve Qx=b","unique minimum of a positive-definite quadratic bowl",
    "stationary operator solution equals geometric minimum")

# 15 — Schur complement
checks=bad=0; mx=0.0
for _ in range(350):
    A0=rng.normal(size=(3,3)); D0=rng.normal(size=(2,2))
    A=A0.T@A0+4*np.eye(3); D=D0.T@D0+4*np.eye(2)
    B=rng.normal(scale=.25,size=(3,2)); C=B.T
    M=np.block([[A,B],[C,D]]); rhs=rng.normal(size=5)
    full=np.linalg.solve(M,rhs); ra,rb=rhs[:3],rhs[3:]
    AinvB=np.linalg.solve(A,B); Ainva=np.linalg.solve(A,ra)
    S=D-C@AinvB; y=np.linalg.solve(S,rb-C@Ainva); x=np.linalg.solve(A,ra-B@y)
    e=float(np.max(np.abs(full-np.r_[x,y])))
    mx=max(mx,e); checks+=1; bad += e>1e-9
rec("Schur complement elimination",43,checks,bad==0,mx,
    "block linear-system elimination","projection/elimination onto a reduced subspace",
    "full solve equals Schur-reduced solve")

# 16 — Convex hull
checks=bad=0; mx=-1e9
for _ in range(450):
    d=int(rng.integers(2,4)); n=int(rng.integers(d+3,2*d+9)); P=rng.normal(size=(n,d))
    hull=ConvexHull(P); lam=rng.dirichlet(np.ones(n)); x=lam@P
    v=float(np.max(hull.equations[:,:-1]@x+hull.equations[:,-1]))
    mx=max(mx,v); checks+=1; bad += v>1e-10
rec("Convex hull",44,checks,bad==0,mx,
    "convex-combination operator sum(lambda_i a_i)","membership in the generated convex region",
    "convex combinations lie inside the hull")

# 17 — LP duality
checks=bad=0; mx=0.0
for _ in range(220):
    m=int(rng.integers(2,7)); n=int(rng.integers(2,7))
    A=rng.uniform(.2,2,size=(m,n)); b=rng.uniform(1,5,size=m); c=rng.uniform(.1,2,size=n)
    p=linprog(-c,A_ub=A,b_ub=b,bounds=[(0,None)]*n,method="highs")
    d=linprog(b,A_ub=-A.T,b_ub=-c,bounds=[(0,None)]*m,method="highs")
    checks+=1
    if not (p.success and d.success): bad+=1; continue
    e=abs(float(-p.fun)-float(d.fun)); mx=max(mx,e); bad += e>1e-8
rec("Linear-programming duality",47,checks,bad==0,mx,
    "primal/dual matrix inequality programs","paired feasible polyhedra with equal supporting optimum",
    "strong-duality optimum equality")

# 18 — Projection / nearest point
checks=bad=0; mx=0.0
for _ in range(500):
    A=rng.normal(size=(7,3))
    while np.linalg.matrix_rank(A)<3: A=rng.normal(size=(7,3))
    y=rng.normal(size=7); p=A@np.linalg.solve(A.T@A,A.T@y)
    e=max(float(np.max(np.abs(A.T@(y-p)))),float(np.max(np.abs(p-A@np.linalg.pinv(A)@y))))
    mx=max(mx,e); checks+=1; bad += e>2e-10
rec("Orthogonal projection",48,checks,bad==0,mx,
    "projection operator P","nearest point in a subspace with orthogonal residual",
    "operator projection equals nearest-point geometry")

# 19 — Ridge / augmented geometry
checks=bad=0; mx=0.0
for _ in range(400):
    X=rng.normal(size=(12,5)); y=rng.normal(size=12); lam=float(rng.uniform(.05,2))
    b1=np.linalg.solve(X.T@X+lam*np.eye(5),X.T@y)
    Xa=np.vstack([X,math.sqrt(lam)*np.eye(5)]); ya=np.r_[y,np.zeros(5)]
    b2=np.linalg.lstsq(Xa,ya,rcond=None)[0]
    e=float(np.max(np.abs(b1-b2))); mx=max(mx,e); checks+=1; bad += e>2e-10
rec("Ridge regression",53,checks,bad==0,mx,
    "(X^T X + lambda I) beta = X^T y","least-squares projection in an augmented geometry",
    "closed-form and augmented-space solutions agree")

# 20 — Gaussian kernel / distance geometry
checks=bad=0; mx=0.0; mineig=float("inf")
for _ in range(350):
    n=int(rng.integers(3,18)); d=int(rng.integers(1,7)); sigma=float(rng.uniform(.4,2.5))
    X=rng.normal(size=(n,d)); q=np.sum(X*X,axis=1)
    dist=q[:,None]+q[None,:]-2*X@X.T
    K1=np.exp(-dist/(2*sigma*sigma))
    K2=np.exp((X@X.T)/(sigma*sigma))*np.exp(-q[:,None]/(2*sigma*sigma))*np.exp(-q[None,:]/(2*sigma*sigma))
    e=float(np.max(np.abs(K1-K2))); ev=np.linalg.eigvalsh((K1+K1.T)/2); mi=float(ev.min())
    mx=max(mx,e); mineig=min(mineig,mi); checks+=1; bad += e>2e-12 or mi<-1e-9
rec("Gaussian positive-definite kernel",54,checks,bad==0,mx,
    "kernel / Gram operator","pairwise-distance geometry exp(-||x-y||^2/(2 sigma^2))",
    "distance and inner-product forms agree; Gram matrix is PSD")

# Build graph
nodes=[]; edges=[]
def N(**x): nodes.append(x)
def E(**x): edges.append(x)

N(id="src:book",type="SOURCE",label=SOURCE_TITLE,
  attributes={"url":SOURCE_PDF,"authors":["Jean Gallier","Jocelyn Quaintance"]})
chapter_ids={}
for i,title in enumerate(chapters,1):
    cid=f"src:chapter:{i:02d}"; chapter_ids[i]=cid
    N(id=cid,type="SOURCE",label=f"Chapter {i}: {title}",
      attributes={"chapter_number":i,"title":title})
    E(id=f"e:book:chapter:{i:02d}",type="CONTAINS",source="src:book",target=cid,ordinal=i)

for i,row in enumerate(rows,1):
    sid=f"sem:test:{i:02d}"; obj=f"obj:test:{i:02d}"; eo=f"op:eo:test:{i:02d}"
    geo=f"op:geo:test:{i:02d}"; cert=f"cert:test:{i:02d}"
    N(id=obj,type="OBJECT",label=row["case"],semantic_id=sid,
      attributes={"source_chapter":row["chapter"],"evidence_class":row["evidence_class"]})
    N(id=eo,type="OPERATOR",label=f"EO — {row['case']}",semantic_id=sid,view="EO",
      attributes={"representation":row["eo_view"]})
    N(id=geo,type="OPERATOR",label=f"GEO — {row['case']}",semantic_id=sid,view="GEO",
      attributes={"representation":row["geo_view"]})
    N(id=cert,type="CERTIFICATE",label=f"Certificate — {row['case']}",
      attributes={"status":row["status"],"checks":row["checks"],"max_error":row["max_error"],"contract":row["contract"]})
    E(id=f"e:{i:02d}:source",type="SOURCED_FROM",source=obj,target=chapter_ids[row["chapter"]])
    E(id=f"e:{i:02d}:eo",type="REPRESENTS",source=eo,target=obj)
    E(id=f"e:{i:02d}:geo",type="REPRESENTS",source=geo,target=obj)
    E(id=f"e:{i:02d}:same",type="SAME_SEMANTICS",source=eo,target=geo,attributes={"contract":row["contract"]})
    E(id=f"e:{i:02d}:verified",type="VERIFIED_BY",source=obj,target=cert)

# Fixture-level dependencies only; not claims about source proof text.
E(id="e:fixture:svd:eigen",type="DEPENDS_ON",source="obj:test:08",target="obj:test:06",
  attributes={"scope":"test-fixture mathematical dependency; not source-proof citation"})
E(id="e:fixture:ridge:projection",type="DEPENDS_ON",source="obj:test:19",target="obj:test:18",
  attributes={"scope":"test-fixture conceptual dependency; not source-proof citation"})

by_id={n["id"]:n for n in nodes}
views=defaultdict(set)
for n in nodes:
    if n.get("semantic_id") and n.get("view"): views[n["semantic_id"]].add(n["view"])

same=True
for e in edges:
    if e["type"]=="SAME_SEMANTICS":
        a,b=by_id[e["source"]],by_id[e["target"]]
        same &= a.get("semantic_id")==b.get("semantic_id") and a.get("view")!=b.get("view")

structural={
    "unique_node_ids":len(by_id)==len(nodes),
    "unique_edge_ids":len({e["id"] for e in edges})==len(edges),
    "edge_endpoints_exist":all(e["source"] in by_id and e["target"] in by_id for e in edges),
    "all_57_chapters_present":sum(n["id"].startswith("src:chapter:") for n in nodes)==57,
    "all_tested_semantics_have_both_views":all(v=={"EO","GEO"} for v in views.values()),
    "same_semantics_edges_match":bool(same),
}
overall=all(r["status"]=="PASS" for r in rows) and all(structural.values())

graph={
    "graph_id":"MAPEOGEO-GALLIER-QUAINTANCE-V0.3",
    "schema_version":"0.3.0",
    "source":{"title":SOURCE_TITLE,"url":SOURCE_PDF},
    "required_views":["EO","GEO"],
    "nodes":nodes,"edges":edges,
}
summary={
    "test_id":"MAPEOGEO-CROSS-DOMAIN-V0.3","seed":SEED,
    "overall_status":"PASS" if overall else "FAIL",
    "source_chapters_scaffolded":57,
    "chapters_with_direct_executable_fixtures":len({r["chapter"] for r in rows}),
    "tested_semantic_objects":len(rows),
    "total_executable_checks":sum(r["checks"] for r in rows),
    "graph_nodes":len(nodes),"graph_edges":len(edges),
    "structural_checks":structural,
    "evidence_classes":{
        "A":"Direct native project parity already established in EO/GEO repositories.",
        "B":"Independent executable mathematical equivalence of operator and geometric/relational views.",
        "C":"Graph-only representability without executable equivalence witness."
    },
    "claim_boundary":{
        "supported":[
            "The tested mathematical semantic objects can be stored with simultaneous EO and GEO views in one graph.",
            "The dual-view ontology remains coherent across the registered cross-domain fixtures.",
            "All registered fixtures satisfy their declared executable equivalence contracts.",
            "The full 57-chapter source hierarchy fits the same graph ontology."
        ],
        "not_supported_yet":[
            "Full semantic extraction of every definition, theorem, and proof in the book.",
            "Universal EO closure over all mathematics.",
            "Universal GEO closure over all mathematics.",
            "Current native GEO-kernel execution for every registered fixture.",
            "Automatic Lean generation or proof-kernel acceptance.",
            "Full reconstruction of the book's proof-dependency graph."
        ]
    },
    "tests":rows,
}
DATA.joinpath("gallier_quaintance_graph_v0_3.json").write_text(json.dumps(graph,indent=2),encoding="utf-8")
DATA.joinpath("gallier_quaintance_results_v0_3.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
print(
    f"MAPEOGEO_V0_3_EXECUTION: {'PASS' if overall else 'FAIL'} "
    f"semantic_objects={len(rows)} checks={summary['total_executable_checks']} "
    f"nodes={len(nodes)} edges={len(edges)}"
)
